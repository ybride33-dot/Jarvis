【J.A.R.V.I.S 멀티파일 PWA — 영구 설치 가이드】
1. github.com 가입(무료) → 우상단 + → New repository → 이름 jarvis, Public → Create
2. "uploading an existing file" 클릭 → 이 폴더의 파일 전부(index.html, app.js, sw.js,
   manifest.json, icon-192.png, icon-512.png, data 폴더 통째) 끌어다 놓기 → Commit
3. Settings → Pages → Branch: main 선택 → Save → 1~2분 대기
4. 폰 크롬에서 https://내아이디.github.io/jarvis/ 접속 → 메뉴(⋮) → "홈 화면에 추가"
5. 설치 완료! 이후엔 인터넷 없이(비행기 모드)도 실행됨 — 서버·502와 완전 무관.

지식 확장법: data/know-pack7.js 식으로 파일을 추가하고 index.html에
<script src="data/know-pack7.js"></script> 한 줄 + app.js의 KNOW.push에 ...KNOW_PACK7 추가.
