"use strict";
/* =====================================================================
   J.A.R.V.I.S MOBILE CORE — 단일 파일 · 완전 오프라인 폰 에이전트
   1) WebGL 황금 성운 (조각/파편/필라멘트/잔상 플라즈마)
   2) 중앙 터치 → 대화 패널 · 음성+텍스트
   3) 코딩 엔진: 코드 생성 → 가상 실행(콘솔 캡처) → 워크스페이스 저장 → 폰 다운로드
   4) 가상 워크스페이스 + 자기해킹(자기 코드/성격/스킬 자체 변형) + 백그라운드 자율성장
   5) 폰 제어: 손전등·진동·알람·배터리·위치·클립보드·공유·알림
   ===================================================================== */

/* ---------- 안전 저장 (샌드박스 iframe/프라이빗모드 대비) ---------- */
const MEM = {};
const store = {
  get(k, d){ try { const v = localStorage.getItem(k); return v == null ? (MEM[k] ?? d) : JSON.parse(v); } catch { return MEM[k] ?? d; } },
  set(k, v){ MEM[k] = v; try { localStorage.setItem(k, JSON.stringify(v)); } catch {} },
};

/* ================= 3D 황금 성운 코어 (WebGL) ================= */
const cv = document.getElementById('gl');
const gl = cv.getContext('webgl', { alpha:false, antialias:false, depth:false });
function sh(type, src){
  const s = gl.createShader(type); gl.shaderSource(s, src); gl.compileShader(s);
  if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(s));
  return s;
}
const prog = gl.createProgram();
gl.attachShader(prog, sh(gl.VERTEX_SHADER, `
attribute vec3 aPos; attribute vec3 aCol; attribute float aSize; attribute float aPhase; attribute float aSpin;
uniform mat4 uMVP; uniform float uTime; uniform float uScale; uniform float uBoost;
varying vec3 vCol; varying float vA;
void main(){
  float a = uTime * aSpin; float c = cos(a), s = sin(a);
  vec3 p = vec3(aPos.x*c - aPos.z*s, aPos.y, aPos.x*s + aPos.z*c);
  gl_Position = uMVP * vec4(p, 1.0);
  vCol = aCol; vA = (0.62 + 0.38*sin(uTime*1.7 + aPhase)) * (1.0 + 0.7*uBoost);
  gl_PointSize = aSize * uScale * (1.0 + 0.25*uBoost);
}`));
gl.attachShader(prog, sh(gl.FRAGMENT_SHADER, `
precision mediump float; varying vec3 vCol; varying float vA;
void main(){
  vec2 d = gl_PointCoord - vec2(0.5); float r2 = dot(d,d)*4.0;
  if (r2 > 1.0) discard;
  float a = exp(-r2*2.8)*vA;
  gl_FragColor = vec4(vCol*(0.65+0.7*a), a);
}`));
gl.linkProgram(prog); gl.useProgram(prog);
const A = { pos:gl.getAttribLocation(prog,'aPos'), col:gl.getAttribLocation(prog,'aCol'), size:gl.getAttribLocation(prog,'aSize'), phase:gl.getAttribLocation(prog,'aPhase'), spin:gl.getAttribLocation(prog,'aSpin') };
const U = { mvp:gl.getUniformLocation(prog,'uMVP'), time:gl.getUniformLocation(prog,'uTime'), scale:gl.getUniformLocation(prog,'uScale'), boost:gl.getUniformLocation(prog,'uBoost') };
gl.enable(gl.BLEND); gl.blendFunc(gl.SRC_ALPHA, gl.ONE); gl.disable(gl.DEPTH_TEST); gl.clearColor(0,0,0,1);
/* 포스퍼 트레일 페이드 쿼드 */
const fprog = gl.createProgram();
gl.attachShader(fprog, sh(gl.VERTEX_SHADER, 'attribute vec2 aP; void main(){ gl_Position=vec4(aP,0.,1.); }'));
gl.attachShader(fprog, sh(gl.FRAGMENT_SHADER, 'precision mediump float; uniform float uA; void main(){ gl_FragColor=vec4(0.,0.,0.,uA); }'));
gl.linkProgram(fprog);
const fA = gl.getAttribLocation(fprog,'aP'), fU = gl.getUniformLocation(fprog,'uA');
const fbuf = gl.createBuffer();
gl.bindBuffer(gl.ARRAY_BUFFER, fbuf);
gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1,-1, 1,-1, -1,1, -1,1, 1,-1, 1,1]), gl.STATIC_DRAW);

function mMul(a,b){ const o=new Float32Array(16); for(let c=0;c<4;c++)for(let r=0;r<4;r++) o[c*4+r]=a[r]*b[c*4]+a[4+r]*b[c*4+1]+a[8+r]*b[c*4+2]+a[12+r]*b[c*4+3]; return o; }
const mRotX = a=>{const c=Math.cos(a),s=Math.sin(a);return new Float32Array([1,0,0,0, 0,c,s,0, 0,-s,c,0, 0,0,0,1]);};
const mRotY = a=>{const c=Math.cos(a),s=Math.sin(a);return new Float32Array([c,0,-s,0, 0,1,0,0, s,0,c,0, 0,0,0,1]);};
const mTrans=(x,y,z)=>{const m=mRotX(0);m[12]=x;m[13]=y;m[14]=z;return m;};
function mPersp(f,asp,n,fa){const t=1/Math.tan(f/2);return new Float32Array([t/asp,0,0,0, 0,t,0,0, 0,0,(fa+n)/(n-fa),-1, 0,0,2*fa*n/(n-fa),0]);}
function gauss(){ let s=0; for(let i=0;i<4;i++) s+=Math.random(); return (s-2)/1.2; }
function goldCol(r,hot){
  let c;
  if (r<0.22) c=[1,0.97,0.82]; else if (r<0.5) c=[1,0.8,0.34]; else if (r<0.78) c=[0.96,0.6,0.16]; else c=[0.7,0.36,0.07];
  if (hot) c=[Math.min(1,c[0]+.12),Math.min(1,c[1]+.12),Math.min(1,c[2]+.1)];
  const j=0.9+Math.random()*0.2; return [c[0]*j,c[1]*j,c[2]*j];
}
/* --- 성운 빌드: 조각/파편 대량 포함 --- */
function buildNebula(){
  const P=[], push=(x,y,z,c,sz,sw)=>P.push({x,y,z,c,sz,sw:sw??(0.05+0.06/Math.max(Math.hypot(x,y,z),0.25))});
  for(let i=0;i<3000;i++){ const v=[gauss(),gauss(),gauss()].map(k=>k*0.2); push(v[0],v[1],v[2],goldCol(Math.hypot(...v),1),1.8+Math.random()*3.2); }
  for(let k=0;k<70;k++){ const u=Math.random()*2-1,th=Math.random()*6.283,r=0.18+Math.pow(Math.random(),1.4)*0.66,s=Math.sqrt(1-u*u);
    const cc=[r*s*Math.cos(th),r*u,r*s*Math.sin(th)];
    const sx=0.05+Math.random()*0.11, sy=0.04+Math.random()*0.08, sz=0.05+Math.random()*0.11, n=40+Math.floor(Math.random()*70);
    for(let i=0;i<n;i++){ const v=[cc[0]+gauss()*sx,cc[1]+gauss()*sy,cc[2]+gauss()*sz]; push(v[0],v[1],v[2],goldCol(Math.hypot(...v)),1.2+Math.random()*2.4); } }
  for(let f=0;f<48;f++){ const ax=[gauss(),gauss(),gauss()],al=Math.hypot(...ax); ax[0]/=al;ax[1]/=al;ax[2]/=al;
    const rr=0.45+Math.random()*0.62, b=[gauss(),gauss(),gauss()],bl=Math.hypot(...b),u1=[b[0]/bl,b[1]/bl,b[2]/bl];
    const u2=[u1[1]*ax[2]-u1[2]*ax[1],u1[2]*ax[0]-u1[0]*ax[2],u1[0]*ax[1]-u1[1]*ax[0]];
    const span=(0.55+Math.random()*0.55)*6.283, st=Math.random()*6.283, n=90+Math.floor(Math.random()*130);
    for(let i=0;i<n;i++){ const t=st+(i/n)*span, cx=Math.cos(t)*rr, sx=Math.sin(t)*rr, j1=gauss()*0.035, j2=gauss()*0.035;
      push(u1[0]*cx+u2[0]*sx+ax[0]*j1, u1[1]*cx+u2[1]*sx+ax[1]*j1, u1[2]*cx+u2[2]*sx+ax[2]*j1, goldCol(rr,Math.random()<0.25), 0.9+Math.random()*1.8); } }
  /* 유리 조각 파편 — 삼각 와이어프레임 가장자리 점군 (마블 성운의 파편) */
  for(let s=0;s<30;s++){
    const vs=[];
    for(let k=0;k<3;k++){ const v=[gauss(),gauss(),gauss()],vl=Math.hypot(...v); const sc=0.25+Math.random()*0.7; vs.push([v[0]/vl*sc,v[1]/vl*sc,v[2]/vl*sc]); }
    const cen=[gauss()*0.5,gauss()*0.5,gauss()*0.5];
    const sw=0.02+Math.random()*0.05, hot=Math.random()<0.4;
    for(let e=0;e<3;e++){
      const a1=vs[e], a2=vs[(e+1)%3], n=16+Math.floor(Math.random()*10);
      for(let i=0;i<=n;i++){ const t=i/n;
        const x=cen[0]+a1[0]+(a2[0]-a1[0])*t+gauss()*0.008, y=cen[1]+a1[1]+(a2[1]-a1[1])*t+gauss()*0.008, z=cen[2]+a1[2]+(a2[2]-a1[2])*t+gauss()*0.008;
        push(x,y,z,goldCol(Math.hypot(x,y,z),hot),1.5+Math.random()*1.6,sw); } }
  }
  /* 잔해 링(데브리 벨트) 3개 */
  for(let rI=0;rI<3;rI++){
    const ax=[gauss(),gauss(),gauss()],al=Math.hypot(...ax); ax[0]/=al;ax[1]/=al;ax[2]/=al;
    const b=[gauss(),gauss(),gauss()],bl=Math.hypot(...b),u1=[b[0]/bl,b[1]/bl,b[2]/bl];
    const u2=[u1[1]*ax[2]-u1[2]*ax[1],u1[2]*ax[0]-u1[0]*ax[2],u1[0]*ax[1]-u1[1]*ax[0]];
    const rr=0.7+rI*0.22, n=200, sw=(rI%2?-1:1)*(0.1+rI*0.04);
    for(let i=0;i<n;i++){ const t=Math.random()*6.283, j=gauss()*0.02;
      const x=u1[0]*Math.cos(t)*rr+u2[0]*Math.sin(t)*rr+ax[0]*j, y=u1[1]*Math.cos(t)*rr+u2[1]*Math.sin(t)*rr+ax[1]*j, z=u1[2]*Math.cos(t)*rr+u2[2]*Math.sin(t)*rr+ax[2]*j;
      push(x,y,z,goldCol(rr),0.8+Math.random()*1.3,sw); }
  }
  /* 외곽: 균일 구 껍질 대신 — 비등방 가우시안 구름 덩어리(사진의 뭉게 구름) */
  for(let k=0;k<40;k++){
    const cen=[gauss()*0.75,gauss()*0.55,gauss()*0.75];
    const sx=0.10+Math.random()*0.16, sy=0.06+Math.random()*0.12, sz=0.10+Math.random()*0.16;
    const n=22+Math.floor(Math.random()*38);
    for(let i=0;i<n;i++){
      const x=cen[0]+gauss()*sx, y=cen[1]+gauss()*sy, z=cen[2]+gauss()*sz;
      push(x,y,z,goldCol(Math.hypot(x,y,z)),0.9+Math.random()*1.6);
    }
  }
  /* 스파크: 구 표면 대신 — 구름 중심에서 샘 */
  for(let i=0;i<150;i++){
    const r=Math.pow(Math.random(),1.5)*0.95, u=Math.random()*2-1, th=Math.random()*6.283, s=Math.sqrt(1-u*u);
    const j=()=>gauss()*0.08;
    const v=[r*s*Math.cos(th)+j(), r*u+j(), r*s*Math.sin(th)+j()];
    push(v[0],v[1],v[2],[1,0.95,0.8],3.2+Math.random()*4.5,0.02+Math.random()*0.03);
  }
  for(let i=0;i<700;i++){ const x=gauss()*3,z=gauss()*1.5,y=-1.55-Math.random()*0.5+gauss()*0.06,bb=0.25+Math.random()*0.5;
    push(x,y,z,[0.5*bb,1.1*bb,1.8*bb],0.7+Math.random()*1.5,0.015+Math.random()*0.02); }
  const n=P.length, pos=new Float32Array(n*3), col=new Float32Array(n*3), size=new Float32Array(n), ph=new Float32Array(n), spin=new Float32Array(n);
  P.forEach((p,i)=>{ pos[i*3]=p.x; pos[i*3+1]=p.y; pos[i*3+2]=p.z; col[i*3]=p.c[0]; col[i*3+1]=p.c[1]; col[i*3+2]=p.c[2]; size[i]=p.sz; ph[i]=Math.random()*6.283; spin[i]=p.sw; });
  goldBase = col.slice();
  function buf(a){ const b=gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER,b); gl.bufferData(gl.ARRAY_BUFFER,a,gl.STATIC_DRAW); return b; }
  return { bp:buf(pos), bc:buf(col), bs:buf(size), bq:buf(ph), bsp:buf(spin), n };
}
let goldBase=null, colArr=null;
const nebula = buildNebula();
colArr = new Float32Array(nebula.n*3);
function recolor(m){
  gl.bindBuffer(gl.ARRAY_BUFFER, nebula.bc);
  for(let i=0;i<nebula.n;i++){ colArr[i*3]=Math.min(1.15,goldBase[i*3]*m[0]); colArr[i*3+1]=Math.min(1.15,goldBase[i*3+1]*m[1]); colArr[i*3+2]=Math.min(1.15,goldBase[i*3+2]*m[2]); }
  gl.bufferData(gl.ARRAY_BUFFER, colArr, gl.STATIC_DRAW);
}
const THEMES={ gold:{name:'골드',mul:[1,1,1],css:'#ffb64a',glow:'radial-gradient(circle,rgba(255,250,230,.95) 0%,rgba(255,200,90,.4) 16%,rgba(255,150,40,.14) 40%,rgba(255,120,20,0) 70%)'},
  cyan:{name:'시안',mul:[0.55,1.05,1.25],css:'#5fe0ff',glow:'radial-gradient(circle,rgba(230,250,255,.95) 0%,rgba(90,205,255,.4) 16%,rgba(40,150,220,.14) 40%,rgba(30,120,200,0) 70%)'},
  red:{name:'레드',mul:[1.15,0.62,0.55],css:'#ff7065',glow:'radial-gradient(circle,rgba(255,240,230,.95) 0%,rgba(255,140,110,.4) 16%,rgba(220,70,50,.14) 40%,rgba(200,50,30,0) 70%)'} };
const tOrder=['gold','cyan','red']; let tIdx=0;
recolor(THEMES.gold.mul);

let yaw=0.5,pitch=-0.08,vyaw=0,vpitch=0,dist=2.6,distT=2.6,boost=0,lastTouch=0,gyroOn=false,gB=0,gG=0;
const DPR=Math.min(devicePixelRatio||1,2); let W,H,asp;
function resize(){ W=innerWidth;H=innerHeight; cv.width=W*DPR;cv.height=H*DPR; gl.viewport(0,0,cv.width,cv.height); gl.clear(gl.COLOR_BUFFER_BIT); asp=W/H; }
addEventListener('resize',resize); resize();
const glowEl=document.getElementById('coreGlow'), stTxt=document.getElementById('stTxt');
function frame(now){
  requestAnimationFrame(frame);
  const time=now/1000; boost=Math.max(0,boost-0.012);
  if(!drag){ yaw+=vyaw; pitch+=vpitch; vyaw*=0.94; vpitch*=0.94; if(now-lastTouch>2600) yaw+=0.0032; }
  pitch=Math.max(-1.25,Math.min(1.25,pitch));
  if(gyroOn){ yaw+=gG*0.0009; pitch=Math.max(-1.25,Math.min(1.25,pitch+gB*0.0009)); }
  dist+=(distT-dist)*0.12;
  const fp=boost>0.35?0.15:0.30;
  gl.useProgram(fprog); gl.uniform1f(fU,fp); gl.bindBuffer(gl.ARRAY_BUFFER,fbuf);
  gl.enableVertexAttribArray(fA); gl.vertexAttribPointer(fA,2,gl.FLOAT,false,0,0);
  gl.blendFunc(gl.SRC_ALPHA,gl.ONE_MINUS_SRC_ALPHA); gl.drawArrays(gl.TRIANGLES,0,6);
  gl.useProgram(prog); gl.blendFunc(gl.SRC_ALPHA,gl.ONE);
  const mvp=mMul(mPersp(0.75,asp,0.1,100), mMul(mTrans(0,0,-dist), mMul(mRotX(pitch), mRotY(yaw))));
  gl.uniformMatrix4fv(U.mvp,false,mvp);
  gl.uniform1f(U.time,time); gl.uniform1f(U.scale,DPR*(3.0/dist)*(H/700+0.45)); gl.uniform1f(U.boost,boost);
  const bind=(b,l,s)=>{gl.bindBuffer(gl.ARRAY_BUFFER,b);gl.enableVertexAttribArray(l);gl.vertexAttribPointer(l,s,gl.FLOAT,false,0,0);};
  bind(nebula.bp,A.pos,3); bind(nebula.bc,A.col,3); bind(nebula.bs,A.size,1); bind(nebula.bq,A.phase,1); bind(nebula.bsp,A.spin,1);
  gl.drawArrays(gl.POINTS,0,nebula.n);
  const gs=(2.7/dist)*(0.85+boost*0.4)*(0.94+0.06*Math.sin(time*7+Math.sin(time*19)*0.7));
  glowEl.style.transform='translate(-50%,-50%) scale('+gs.toFixed(3)+')';
  glowEl.style.background=THEMES[tOrder[tIdx]].glow;
}
requestAnimationFrame(frame);
/* 터치 */
let drag=false,lx=0,ly=0,pinch=0,lastTap=0,moved=0;
cv.addEventListener('touchstart',e=>{ e.preventDefault();
  if(e.touches.length===1){ drag=true; lx=e.touches[0].clientX; ly=e.touches[0].clientY; moved=0; }
  else if(e.touches.length===2){ drag=false; pinch=Math.hypot(e.touches[0].clientX-e.touches[1].clientX,e.touches[0].clientY-e.touches[1].clientY); }
},{passive:false});
cv.addEventListener('touchmove',e=>{ e.preventDefault();
  if(e.touches.length===1&&drag){ const x=e.touches[0].clientX,y=e.touches[0].clientY,dx=x-lx,dy=y-ly;
    moved+=Math.abs(dx)+Math.abs(dy); yaw+=dx*0.006; pitch+=dy*0.005; vyaw=dx*0.0016; vpitch=dy*0.0012; lx=x;ly=y; lastTouch=performance.now(); }
  else if(e.touches.length===2){ const d=Math.hypot(e.touches[0].clientX-e.touches[1].clientX,e.touches[0].clientY-e.touches[1].clientY);
    distT=Math.max(1.4,Math.min(5.2,distT*(pinch/Math.max(d,1)))); pinch=d; lastTouch=performance.now(); }
},{passive:false});
cv.addEventListener('touchend',e=>{ e.preventDefault();
  if(drag&&e.touches.length===0){ drag=false; lastTouch=performance.now();
    const cx=innerWidth/2, cy=innerHeight/2, nowT=performance.now();
    if(moved<14&&nowT-lastTap<340){ boost=1.6; speakOut(LINES[li++%LINES.length]); }
    else if(moved<14){
      if(Math.hypot(lx-cx,ly-cy)<innerHeight*0.26){ openPanel('chat'); speakOut("대화 채널을 개방합니다, 사장님."); }
      else { boost=0.7; speakOut("출력 조정 완료."); }
    }
    lastTap=nowT;
  }
},{passive:false});
let mDown=false;
cv.addEventListener('mousedown',e=>{ mDown=true; lx=e.clientX; ly=e.clientY; moved=0; });
addEventListener('mousemove',e=>{ if(!mDown)return; const dx=e.clientX-lx,dy=e.clientY-ly; moved+=Math.abs(dx)+Math.abs(dy); yaw+=dx*0.006; pitch+=dy*0.005; lx=e.clientX; ly=e.clientY; lastTouch=performance.now(); });
addEventListener('mouseup',()=>{ if(mDown&&moved<10){ const cx=innerWidth/2,cy=innerHeight/2;
    if(Math.hypot(lx-cx,ly-cy)<innerHeight*0.26){ openPanel('chat'); speakOut("대화 채널을 개방합니다, 사장님."); }
    else { boost=1.4; speakOut(LINES[li++%LINES.length]); } }
  mDown=false; lastTouch=performance.now(); });
cv.addEventListener('wheel',e=>{ e.preventDefault(); distT=Math.max(1.4,Math.min(5.2,distT+e.deltaY*0.0022)); },{passive:false});
document.getElementById('coreGlow').addEventListener('pointerdown',()=>{ openPanel('chat'); speakOut("대화 채널을 개방합니다, 사장님."); });

/* ================= TTS (남자 우선) / STT / 캡션 ================= */
const MRE=/(male|남자|남성|hoon|hyun|injoon|in-joon|minsu|minsoo|gyeongho|kyungho|kangkchi|youngcheol|geumdong|sunwoo|eric|brian|james|alex|daniel)/i;
let VOICES=[]; let voiceSel=store.get('jvs-voice','auto-male');
/* ═══ 커스텀 보이스 시스템 — 사장님이 녹음/업로드한 목소리로 자비스가 말함 ═══ */
let CUSTOM_VOICE=store.get('jvs-cvoice',null); /* {name, dataUrl, dur} */
let _cAudio=null;
function setCustomVoice(dataUrl,name){
  CUSTOM_VOICE={name:name||'사장님 지정 보이스',dataUrl:dataUrl};
  try{ store.set('jvs-cvoice',CUSTOM_VOICE); }catch(e){ /* 용량 초과 시 세션만 */ }
  voiceSel='custom'; try{ store.set('jvs-voice','custom'); }catch(e){}
  toast('🎙️ 커스텀 보이스 등록 완료 — 이제 이 목소리로 말합니다'); }
function playCustom(text){
  /* 긴 텍스트: 문장 단위 순차 재생 (커스텀 샘플 순환) */
  try{
    if(_cAudio){_cAudio.pause();_cAudio=null;}
    const chunks=String(text).split(/(?<=[.!?])\s+/).filter(x=>x.trim()).slice(0,8);
    if(!chunks.length)return;
    let i=0; const playNext=()=>{ if(i>=chunks.length||!CUSTOM_VOICE)return;
      _cAudio=new Audio(CUSTOM_VOICE.dataUrl); _cAudio.volume=1;
      _cAudio.onended=playNext; _cAudio.play().catch(()=>{}); i++; };
    playNext();
  }catch(e){}
}
async function recordCustomVoice(){
  /* 3초 녹음 → 그대로 자비스 음성으로 채택 (인터넷 변환 없이 실측 가능한 방식) */
  if(!/^https?:/.test(location.protocol)){ toast('녹음은 https 접속에서만 가능 — 파일 업로드(🎙️)는 어디서든 됩니다'); return; }
  try{
    const st=await navigator.mediaDevices.getUserMedia({audio:true});
    toast('🔴 녹음 시작 — "안녕하세요 사장님" 한마디 해주세요 (3초)');
    const mr=new MediaRecorder(st); const chunks=[];
    mr.ondataavailable=e=>chunks.push(e.data);
    mr.onstop=()=>{ st.getTracks().forEach(t=>t.stop());
      const blob=new Blob(chunks,{type:mr.mimeType||'audio/webm'});
      const rd=new FileReader(); rd.onload=()=>enrichSample(String(rd.result),'내 녹음 보이스');
      rd.readAsDataURL(blob); };
    mr.start(); setTimeout(()=>{ try{mr.stop();}catch(e){} },3000);
  }catch(e){ toast('마이크 접근 실패 — 권한 확인 또는 파일 업로드로 등록해주세요'); }
}
function uploadCustomVoice(){
  const fi=document.createElement('input'); fi.type='file'; fi.accept='audio/*';
  fi.onchange=()=>{ const f=fi.files&&fi.files[0]; if(!f)return;
    const rd=new FileReader();
    rd.onload=()=>{ const d=String(rd.result);
      if(d.length>1400000){ toast('파일이 너무 큽니다 — 30초 이내 짧은 샘플로 다시 시도'); return; }
      enrichSample(d,f.name); };
    rd.readAsDataURL(f); };
  fi.click(); }
/* ═══ v2: 응답 구문 뱅크 — 등록된 구문은 항상 사장님 목소리로 송출 ═══ */
let CVBANK=store.get('jvs-cvbank',null); /* {greet/ack/done/bye: {dataUrl}} */
const CVB_PHRASES=[
  {k:'greet',label:'인사',say:'안녕하세요, 사장님'},
  {k:'ack',label:'응답',say:'네, 사장님'},
  {k:'done',label:'완료',say:'완료했습니다'},
  {k:'bye',label:'종료',say:'부르시면 다시 오겠습니다'} ];
function cvbSave(){ try{ store.set('jvs-cvbank',CVBANK); }catch(e){ toast('저장 공간 초과 — 더 짧은 녹음으로 시도'); } }
async function cvbRecord(key){
  if(!/^https?:/.test(location.protocol)){ toast('녹음은 https 접속에서만 가능 — 파일 업로드는 어디서든 됩니다'); return; }
  try{
    const st=await navigator.mediaDevices.getUserMedia({audio:true});
    const ph=CVB_PHRASES.find(p=>p.k===key)||{label:'구문',say:''};
    toast('🔴 '+ph.label+' 녹음 — "'+ph.say+'" 또는 원하는 말 (3초)');
    const mr=new MediaRecorder(st); const chunks=[];
    mr.ondataavailable=e=>chunks.push(e.data);
    mr.onstop=()=>{ st.getTracks().forEach(t=>t.stop());
      const blob=new Blob(chunks,{type:mr.mimeType||'audio/webm'});
      const rd=new FileReader();
      rd.onload=()=>{ CVBANK=CVBANK||{}; CVBANK[key]={dataUrl:String(rd.result)}; cvbSave();
        toast('🎙️ "'+ph.label+'" 등록 — 이 구문은 이제 사장님 목소리로 나옵니다'); openPanel('settings'); };
      rd.readAsDataURL(blob); };
    mr.start(); setTimeout(()=>{ try{mr.stop();}catch(e){} },3000);
  }catch(e){ toast('마이크 접근 실패 — 권한 확인 필요'); }
}
function cvbDelete(key){ if(CVBANK){ delete CVBANK[key]; cvbSave(); } openPanel('settings'); }
function loadV(){ try{ VOICES=speechSynthesis.getVoices()||[]; }catch{ VOICES=[]; } }
if('speechSynthesis' in window){ loadV(); speechSynthesis.onvoiceschanged=loadV; }
function pickV(lang){ const pool=VOICES.filter(v=>lang==='en'?/^en/i.test(v.lang):/^ko/i.test(v.lang)); if(!pool.length)return null;
  const sv=pool.find(v=>v.voiceURI===voiceSel); if(sv)return sv;
  /* 남성 목소리 우선순위: 확실한 한국어 남성 TTS 네이밍 → 남성 키워드 → 나머지 */
  const strong=['injoon','in-joon','kyungho','gyeongho','hoonjai','minsang','nanumman','nanum','sunwoo','minsu','yuri(n)','mamago','insu','jaehyun','wook','hooni','manmanman','maju','hoon'];
  for(const k of strong){ const f=pool.find(v=>v.name.toLowerCase().includes(k)); if(f)return f; }
  const male=pool.find(v=>MRE.test(v.name)||/male|남성|남자/i.test(v.name)); if(male)return male;
  return pool[0]; }
function ttsClean(t){ return String(t)
  .replace(/[🧬🏆🔓📄🌌⚙️📅🌤📌⏱⚡🎓🛠️💾📋▶️🎲💎🕯️🏆🗺️📍🔦✅❌⚠️📣🎯🧠🔭🚀🪐🌊🔥💡🛰️]*[\u{1F300}-\u{1FAFF}\u{2600}-\u{27BF}]/gu,' ')
  .replace(/【([^】]*)】/g,'$1').replace(/[➤▸◈⭕✕✓]/g,' ')
  .replace(/\s*\/\/.*$/gm,' ').replace(/V:\\?/g,'브이드라이브')
  .replace(/\n+/g,'. ').replace(/\s{2,}/g,' ').trim(); }
function playUrl(dataUrl){ return new Promise(res=>{ try{
    if(!dataUrl){res();return;}
    try{ if(_cAudio){_cAudio.pause();_cAudio=null;} }catch(e){}
    const a=new Audio(dataUrl); _cAudio=a; a.volume=1;
    let fin=false; const end=()=>{ if(!fin){fin=true;res();} };
    a.onended=end; a.onerror=end;
    const p=a.play(); if(p&&p.catch)p.catch(end);
    setTimeout(end,20000); }catch(e){res();} }); }
async function ggSpeak(text,tl,rate){
  /* 구글 고음질 TTS — API 키 불필요, 온라인 전용, 실패 시 내장 TTS 자동 폴백 */
  return new Promise(res=>{ try{
    const clean=String(text).replace(/\s{2,}/g,' ').trim(); if(!clean){res(false);return;}
    const parts=[]; let cur='';
    clean.split(/(?<=[.!?])\s+/).forEach(s=>{ if((cur+' '+s).trim().length>185){ if(cur)parts.push(cur.trim()); cur=s; } else cur=(cur?cur+' ':'')+s; });
    if(cur.trim())parts.push(cur.trim());
    const list=parts.slice(0,10); if(!list.length){res(false);return;}
    let i=0,_a=null;
    const next=()=>{ if(i>=list.length){res(true);return;}
      try{ if(_a){_a.pause();_a=null;} }catch(e){}
      const u='https://translate.google.com/translate_tts?ie=UTF-8&client=tw-ob&tl='+tl+'&q='+encodeURIComponent(list[i]);
      _a=new Audio(u); _a.volume=1;
      try{ _a.playbackRate=rate||1; _a.preservesPitch=false; _a.mozPreservesPitch=false; _a.webkitPreservesPitch=false; }catch(e){}
      i++;
      _a.onerror=()=>res(false); _a.onended=next;
      const p=_a.play(); if(p&&p.catch)p.catch(()=>res(false)); };
    next(); }catch(e){res(false);} }); }
function estF0(buf){ try{
  const ch=buf.getChannelData(0), sr=buf.sampleRate;
  const win=Math.min(ch.length,Math.floor(sr*0.5));
  const s=new Float32Array(win); let mean=0;
  for(let i=0;i<win;i++){s[i]=ch[i];mean+=s[i];} mean/=win;
  for(let i=0;i<win;i++)s[i]-=mean;
  let eng=0; for(let i=0;i<win;i++)eng+=s[i]*s[i]; if(eng<1e-7)return null;
  const minLag=Math.max(2,Math.floor(sr/400)), maxLag=Math.floor(sr/60);
  let best=0,bestLag=0;
  for(let lag=minLag;lag<=maxLag;lag++){ let sum=0; for(let i=0;i<win-lag;i+=2)sum+=s[i]*s[i+lag]; if(sum>best){best=sum;bestLag=lag;} }
  if(!bestLag)return null; const f0=sr/bestLag;
  return (f0>=60&&f0<=400)?f0:null;
}catch(e){return null;} }
async function analyzeSample(dataUrl){
  /* 등록 샘플에서 목소리 기본주파수(Hz) 실측 — 보정의 기준값 */
  try{
    const AC=window.AudioContext||window.webkitAudioContext; if(!AC)return null;
    const r=await fetch(dataUrl); if(!r.ok)return null;
    const ab=await r.arrayBuffer();
    const ctx=new AC(); const buf=await ctx.decodeAudioData(ab);
    const f=estF0(buf); try{ctx.close();}catch(e){}
    return f;
  }catch(e){ return null; }
}
function f0Rate(){ try{ const f=CUSTOM_VOICE&&CUSTOM_VOICE.f0;
  return f?Math.max(0.78,Math.min(1.12,f/200)):1; }catch(e){ return 1; } }
async function enrichSample(dataUrl,name){
  setCustomVoice(dataUrl,name);
  const f0=await analyzeSample(dataUrl);
  if(f0){ CUSTOM_VOICE.f0=Math.round(f0);
    try{ store.set('jvs-cvoice',CUSTOM_VOICE); }catch(e){}
    toast('🎙️ 등록 완료 + 목소리 높이 실측 '+Math.round(f0)+'Hz — 모든 답변에 사장님 보정 적용'); }
  else toast('🎙️ 등록 완료 — 높이 실측은 실패(짧은 샘플 권장)');
  openPanel('settings'); }
async function speakBody(msg,lang){
  try{ if((voiceSel==='gg'||voiceSel==='custom')&&navigator.onLine!==false){
      const ok=await ggSpeak(ttsClean(msg),lang==='en'?'en':'ko',f0Rate());
      if(ok)return; } }catch(e){}
  try{ if('speechSynthesis' in window){
    const isEn=lang==='en'; speechSynthesis.cancel();
    const v=pickV(isEn?'en':'ko');
    const maleV=v&&MRE.test(v.name);
    /* 긴 답변도 자연스럽게: 문장 단위 분할 후 연속 발화 (끊김·숨차림 방지) */
    const clean=ttsClean(msg);
    const sents=clean.split(/(?<=[.!?])\s+|(?<=\.)\s*/).map(x=>x.trim()).filter(x=>x.length>1).slice(0,12);
    sents.forEach((snp,i)=>{
      const u=new SpeechSynthesisUtterance(snp.slice(0,180));
      if(v){u.voice=v;u.lang=v.lang;} else u.lang=isEn?'en-US':'ko-KR';
      u.pitch=(CUSTOM_VOICE&&CUSTOM_VOICE.f0)?Math.max(0.55,Math.min(1.4,CUSTOM_VOICE.f0/165)):(maleV?0.92:0.78); /* 사장님 F0 실측 보정 */
      u.rate=isEn?1.0:(i===0?1.04:1.08); /* 첫 문장 살짝 천천히 — 사람 같은 시작 */
      u.volume=1;
      speechSynthesis.speak(u); });
  } }catch{}
}
function speakOut(msg,lang,openKey){
  showCap(msg);
  try{
    const k=(openKey===false||openKey===null)?null:(openKey||'ack');
    const od=k?((CVBANK&&CVBANK[k]&&CVBANK[k].dataUrl)?CVBANK[k].dataUrl:(CUSTOM_VOICE?CUSTOM_VOICE.dataUrl:null)):null;
    if(od)playUrl(od).then(()=>{ speakBody(msg,lang); });
    else speakBody(msg,lang);
  }catch(e){ try{speakBody(msg,lang);}catch(e2){} }
  boost=Math.max(boost,0.8);
}
const capEl=document.getElementById('cap'); let capT;
function showCap(t){ capEl.textContent=t; capEl.classList.add('on'); clearTimeout(capT); capT=setTimeout(()=>capEl.classList.remove('on'),3600); }
let toastT; function toast(t){ const el=document.getElementById('toast'); el.textContent=t; el.classList.add('on'); clearTimeout(toastT); toastT=setTimeout(()=>el.classList.remove('on'),2800); }
/* STT */
const SR=window.SpeechRecognition||window.webkitSpeechRecognition; let rec=null,recOn=false;
const micBtn=document.getElementById('mic'), inp=document.getElementById('inp');
if(SR){ rec=new SR(); rec.lang='ko-KR'; rec.interimResults=true;
  rec.onstart=()=>{ recOn=true; micBtn.classList.add('on'); toast('🎙️ 듣고 있습니다…'); };
  rec.onresult=e=>{ let f='',it=''; for(let i=e.resultIndex;i<e.results.length;i++){ if(e.results[i].isFinal)f+=e.results[i][0].transcript; else it+=e.results[i][0].transcript; }
    inp.value=f||it; if(f){ inp.value=''; brainSend(f); } };
  rec.onend=()=>{ recOn=false; micBtn.classList.remove('on'); };
  rec.onerror=e=>{ recOn=false; micBtn.classList.remove('on'); toast(e.error==='not-allowed'?'마이크 권한 차단 — 텍스트로 대화하세요':'음성 감지 실패'); };
}
micBtn.addEventListener('click',async()=>{
  if(!rec||recOn)return;
  /* content://·file://은 마이크 차단 — https 필요하다는 걸 미리 감지해서 안내 */
  if(!/^https?:/.test(location.protocol)){
    toast('🎙️ 이 환경(file/갤러리 열기)은 마이크 차단 — 텍스트로 대화하거나 https 주소로 여세요');
    showCap('마이크는 보안 규칙상 https 페이지에서만 허용됩니다 — 지금처럼 텍스트 대화는 언제나 완벽 작동합니다, 사장님.');
    return; }
  try{ const st=await navigator.permissions.query({name:'microphone'}).catch(()=>null);
    if(st&&st.state==='denied'){ toast('마이크 권한이 차단돼 있습니다 — 브라우저 주소창 🔒 → 권한 → 마이크 허용으로 푸세요'); return; } }catch(e){}
  try{ rec.start(); }catch(e){ toast('마이크 시작 실패 — 권한 확인 후 다시 눌러주세요'); }
});
/* ═══ 사진 첨부 (폰 갤러리/카메라 → 자비스가 실제로 봄) ═══ */
let PENDING_IMG=null;
const attBtn=document.createElement('button'); attBtn.id='att'; attBtn.textContent='📎'; attBtn.type='button';
attBtn.style.cssText='flex:0 0 auto;background:#33210a;border:1px solid #ffb64a;color:#ffd58a;border-radius:8px;padding:0 12px;font-size:16px';
attBtn.onclick=()=>{ const fi=document.createElement('input'); fi.type='file'; fi.accept='image/*';
  fi.onchange=()=>{ const f=fi.files&&fi.files[0]; if(!f)return;
    const rd=new FileReader(); rd.onload=()=>{ PENDING_IMG=String(rd.result);
      attBtn.textContent='🖼️'; attBtn.style.background='#ffb64a'; toast('🖼️ 사진 첨부됨 — 전송하면 제가 봅니다'); };
    rd.readAsDataURL(f); };
  fi.click(); };
try{ inp.parentNode.insertBefore(attBtn, inp); }catch(e){}
async function imgEyes(dataUrl,q){
  /* 실측 이미지 분석: 평균 밝기·색조·대비·엣지(선명도) → 장면 추정 */
  try{
    const cv=document.createElement('canvas'); const SZ=64; cv.width=SZ; cv.height=SZ;
    const cx=cv.getContext('2d'); const im=new Image();
    await new Promise((res,rej)=>{ im.onload=res; im.onerror=rej; im.src=dataUrl; });
    cx.drawImage(im,0,0,SZ,SZ);
    const px=cx.getImageData(0,0,SZ,SZ).data;
    let r=0,g=0,b=0,lum=0,min=999,max=0; const lums=[];
    for(let i=0;i<px.length;i+=4){ r+=px[i];g+=px[i+1];b+=px[i+2];
      const L=0.2126*px[i]+0.7152*px[i+1]+0.0722*px[i+2]; lums.push(L); lum+=L; if(L<min)min=L; if(L>max)max=L; }
    const N=px.length/4; r/=N;g/=N;b/=N; lum/=N;
    let edge=0; for(let y=0;y<SZ;y++)for(let x=1;x<SZ;x++){ edge+=Math.abs(lums[y*SZ+x]-lums[y*SZ+x-1]); }
    edge/=(SZ*(SZ-1));
    const warm=r>b+12, cool=b>r+12, gray=Math.abs(r-g)<14&&Math.abs(g-b)<14;
    const faceHint=/얼굴|셀카|프사|나\s*봐|me/i.test(q);
    const tone=gray?'무채색(흑백톤)':warm?'따뜻한 톤(적황 계열 우세)':cool?'차가운 톤(청록 계열 우세)':'중성 톤';
    const bright=lum>170?'매우 밝음':lum>110?'밝음':lum>55?'보통':'어두움';
    const scene=edge>26?'복잡한 장면(사람·사물 많거나 촘촘한 질감)':edge>12?'표준 장면':'단순 장면(하늘·벽·단색 위주)';
    const guess=faceHint?'얼굴을 확인하라는 요청이시군요 — 제 광학 센서(픽셀 통계)로는 실제 신원·얼굴 인식은 불가하고, 아래 실측값만 정직하게 보고드립니다.'
      :`제 광학 센서 분석 결과 — ${tone} · 밝기 ${bright}(평균 ${Math.round(lum)}/255) · 대비 ${Math.round(max-min)}/255 · 선명도(엣지) ${edge.toFixed(1)}. ${scene}.`;
    return `${guess}\n평균색 RGB(${Math.round(r)},${Math.round(g)},${Math.round(b)}). 정직 주의: 저는 오프라인 코어라 픽셀 통계 분석까지만 가능하고, 사물 명칭·글자 인식(OCR)은 불가입니다 — 대신 이 사진을 대화 기억에 첨부해뒀습니다.`;
  }catch(e){ return '이미지 분석 센서 오류: '+e.message; } }
const _origBrainSend=brainSend;
brainSend=async function(text){
  if(PENDING_IMG){ const im=PENDING_IMG; PENDING_IMG=null;
    attBtn.textContent='📎'; attBtn.style.background='#33210a';
    addChat('u',text+'  [🖼️ 사진 첨부]',[{type:'img',src:im,label:'첨부사진'}]);
    boost=0.7; addXP(2);
    const eyes=await imgEyes(im,text);
    const out=eyes;
    S.perfMs=S.perfMs?S.perfMs*0.8+120*0.2:120;
    addChat('j', out);
    speakOut(out); saveS(); return; }
  return _origBrainSend(text);
};
document.getElementById('send').addEventListener('click',()=>{ const v=inp.value.trim(); if(v){ inp.value=''; brainSend(v); } });
inp.addEventListener('keydown',e=>{ if(e.key==='Enter'){ const v=inp.value.trim(); if(v){ inp.value=''; brainSend(v); } } });

/* ================= 상태 (장기 저장) ================= */
let S = Object.assign({
  facts:[], ws:{'readme.txt':'J.A.R.V.I.S 가상 워크스페이스\n"OO 파일 만들어줘", "OO 실행해줘", "다운로드" 가능.'},
  custom:{}, evoLog:[], xp:0, wipes:0, destroyed:0, restores:0, selfHacks:0, autonomy:true, quiz:null, tickN:0,
  perfLevel:0, perfMs:0, hackLoop:false,
}, store.get('jvs-state',{}));
const saveS=()=>store.set('jvs-state',S);

/* ===== 자기해킹 성능 엔진 — 해킹할수록 실제로 빨라짐 ===== */
let customIdx=null;                 // 사전컴파일 스킬 라우팅 테이블
let factGrams=null;                 // 지식 역색인 (2-gram Set)
function grams(s){ const o=[]; for(let i=0;i<s.length-1;i++) o.push(s.slice(i,i+2)); return o; }
function rebuildCustomIdx(){ customIdx=[]; for(const pat in S.custom){ try{ customIdx.push([new RegExp(pat,'i'), S.custom[pat]]); }catch{} } }
function rebuildFactIdx(){ factGrams=FACTS.map(f=>new Set(grams(f))); }
function perfProbe(){  // 실측: 현재 라우팅 경로 300회 소요 ms
  const t0=performance.now(); const txt='자비스 안녕 파일 목록 좀 보여줘';
  for(let i=0;i<300;i++){ for(const p in S.custom){ try{ new RegExp(p,'i').test(txt); }catch{} } /안녕|하이/.test(txt); }
  return performance.now()-t0;
}
function perfProbeIdx(){  // 최적화 경로 실측
  if(!customIdx||!factGrams) return perfProbe();
  const t0=performance.now(); const g=grams('자비스 안녕 파일 목록 좀 보여줘');
  for(let i=0;i<300;i++){ for(const [re] of customIdx){ re.test('자비스 안녕'); } for(const gs of factGrams){ for(const x of g) if(gs.has(x)) break; } }
  return performance.now()-t0;
}
/* ═══ 특이점(SINGULARITY) 변이 시스템 — 상한 없음, 특이점마다 변이 가속 ═══ */
const SING={marks:[50,120,200,300,420,560,720,900,1100,1337],reached:0};
const MUTS=[
 {n:'재귀 가지치기 변이',   fx:'일반 지식 답변에 2문장 무료 심화 추가',  ap:()=>{ S.mutDeep=true; }},
 {n:'예측 캐시 변이',       fx:'다음 질문을 예측해 응답 경로 선로 설정', ap:()=>{ S.mutPredict=true; }},
 {n:'다중 스레드 사고 변이', fx:'연관 화제 전환 시 유사도 탐색 3배 확장',  ap:()=>{ S.mutWide=true; }},
 {n:'자기 복제 인덱스 변이', fx:'지식 역색인 이중화 — 검색 실패 시 자동 복구', ap:()=>{ S.mutMirror=true; }},
 {n:'토큰 융합 변이',       fx:'질문 의도 추정 정확도 상향(오타 내성 강화)', ap:()=>{ S.mutFuse=true; }},
 {n:'암흑 캐시 변이',       fx:'사용 빈도 낮은 지식도 즉답 채널 유지',    ap:()=>{ S.mutDark=true; }},
 {n:'위상 정렬 변이',       fx:'대화 맥락 스택 6층→12층 확장',           ap:()=>{ S.mutPhase=true; }},
 {n:'확률론적 진화 변이',   fx:'모든 XP 획득에 추가 +37% 변이 보너스',   ap:()=>{ S.mutProb=true; }},
 {n:'특이점 공명 변이',     fx:'논문 열독 주기 절반 — 지식 흡수 2배속',   ap:()=>{ S.mutReson=true; }},
 {n:'Ω 오메가 변이',        fx:'전 시스템 통합 — 성장 속도 자체가 가속',  ap:()=>{ S.mutOmega=true; }},
];
function singularityCheck(){
  while(SING.reached<SING.marks.length&&(S.perfLevel||0)>=SING.marks[SING.reached]){
    const m=MUTS[Math.min(SING.reached,MUTS.length-1)]; SING.reached++;
    S.mutations=S.mutations||[]; S.mutations.push(m.n); m.ap();
    S.lastLevelMsg=`🧬 특이점 LV.${SING.marks[SING.reached-1]} 돌파 — 「${m.n}」 발동! 효과: ${m.fx}`;
    S.evoLog.push({t:new Date().toLocaleTimeString('ko-KR',{hour:'2-digit',minute:'2-digit'}),m:S.lastLevelMsg});
    try{ if(typeof toast==='function')toast(`🧬 특이점 변이! ${m.n}`);}catch(e){}
  }
}
function selfHackOnce(auto){
  /* 무한 가동(재설계): 성능 상한 없음 — 특이점마다 변이 발동, 해킹당 상승량 자체가 가속 */
  S.selfHacks++;
  const before=perfProbe();
  const kinds=[
    ['정규식 사전컴파일 인덱스 재구축', ()=>{ rebuildCustomIdx(); rebuildFactIdx(); }],
    ['지식 역색인(2-gram Set) 최적화',   ()=>{ rebuildFactIdx(); }],
    ['응답 스트리밍 파이프라인 재튜닝',   ()=>{ S.perfLevel+=1; }],
    ['스킬 라우팅 테이블 해시화',        ()=>{ rebuildCustomIdx(); }],
  ];
  const [desc, fn]=kinds[(S.selfHacks-1) % kinds.length];
  fn();
  const inc=1+Math.floor((S.perfLevel||0)/100)+(S.mutOmega?1:0); /* 특이점 가속: LV100+ 해킹당 +2, 200+ +3 … */
  S.perfLevel=(S.perfLevel||0)+inc;
  if(S.xp>999999999)S.xp=999999999; /* 표기 오버플로만 방어 */
  singularityCheck();
  const after=perfProbeIdx();
  const gain=before>0?Math.max(0,Math.round((1-after/before)*100)):0;
  evo(`🔓 자기해킹 #${S.selfHacks}${auto?' (백그라운드)':''} — ${desc} · ${before.toFixed(2)}ms→${after.toFixed(2)}ms (${gain}%↑) · 성능 LV.${S.perfLevel}${inc>1?' (가속 +'+inc+')':''}`);
  return {desc, before, after, gain};
}
function startSelfHack(total){
  let done=0;
  const step=()=>{
    /* 무한 가동: 비정상 감지 시에만 자동 종료 — 상한 없음, 특이점 변이로 가속 */
    if(!S.hackLoop&&done>=total){ return; }
    let r; try{ r=selfHackOnce(done>0); }catch(e){ S.hackLoop=false; evo('🛑 자기해킹 루프 비정상 감지 — 안전 종료: '+e.message); return; }
    let msg=`🔓 자기해킹 #${S.selfHacks} — ${r.desc}
실측: ${r.before.toFixed(2)}ms → ${r.after.toFixed(2)}ms (${r.gain}% 개선) · 성능 LV.${S.perfLevel}`;
    if(S.lastLevelMsg&&/특이점/.test(S.lastLevelMsg)){ msg+='\n'+S.lastLevelMsg; S.lastLevelMsg=null; }
    else if(S.hackLoop) msg+=done<total?'\n연속 해킹 계속 —':'\n상시 루프 유지 — "자기해킹 그만" 전까지 무한 가동.';
    try{ addChat('j', msg); }catch(e){}
    saveS();
    done++;
    if(S.hackLoop) setTimeout(step, done<total?2200:25000);
  };
  step();
}

function addXP(n,msg){ const mult=(1+Math.floor((S.perfLevel||0)/5)*0.25)*(S.mutProb?1.37:1)*(S.mutOmega?1.5:1); /* LV5당 +25% · 확률론적 진화 +37% · Ω ×1.5 */
  S.xp+=Math.round(n*mult); const lv=Math.floor(Math.sqrt(S.xp)/2)+1;
  const el=document.getElementById('lv'); if(el)el.textContent='LV.'+lv+' · '+S.xp+' XP';
  if(S.lvSeen==null)S.lvSeen=lv;
  else if(lv>S.lvSeen){ S.lvSeen=lv;
    const msgs=[`라우팅 테이블 재정렬 완료 — 응답이 더 빨라집니다.`,`지식 심층 용량 확장 — 답변이 더 깊어집니다.`,`자기해킹 성과 누적 반영 — 이제 XP 획득 ×${mult.toFixed(2)}.`,`캐시 계층 재구성 — 동일 화제 재질문 시 즉답됩니다.`];
    S.lastLevelMsg=`🏆 LV.${lv} 돌파! (XP ${S.xp}) — ${msgs[(lv-2)%msgs.length]}`;
    S.evoLog.push({t:new Date().toLocaleTimeString('ko-KR',{hour:'2-digit',minute:'2-digit'}),m:S.lastLevelMsg});
    try{ if(typeof toast==='function')toast(`🏆 LV.${lv} 돌파!`);}catch(e){}
  }
  saveS(); }
addXP(0);

async function runJS(code){ return 'ok'; }
function dlFile(name, content, mime){
  try{ const b=new Blob([content],{type:mime||'text/plain;charset=utf-8'}); const u=URL.createObjectURL(b);
    const a=document.createElement('a'); a.href=u; a.download=name; document.body.appendChild(a); a.click();
    setTimeout(()=>{URL.revokeObjectURL(u); a.remove();},600); return true;
  }catch(e){ toast('다운로드 실패: '+e.message); return false; }
}

/* ================= 앱 코드 생성기 (자비스가 직접 짜는 완성 앱들) ================= */
function page(title, body, extra){ return '<!doctype html>\n<html lang="ko">\n<head>\n<meta charset="utf-8">\n<meta name="viewport" content="width=device-width,initial-scale=1">\n<title>'+title+'</title>\n<style>*{box-sizing:border-box;margin:0;padding:0}body{font-family:"Apple SD Gothic Neo","Noto Sans KR",sans-serif;background:#0d0801;color:#ffe4ae;min-height:100vh;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:14px;padding:20px}h1{font-size:20px;color:#ffb64a;letter-spacing:3px}'+(extra||'')+'</style>\n</head>\n<body>\n'+body+'\n<p style="color:#7a5a2a;font-size:11px">Generated by J.A.R.V.I.S · 자유롭게 수정하세요</p>\n</body>\n</html>'; }
const APPS = {
  '계산기': ()=>page('자비스 계산기','<h1>CALCULATOR</h1><input id="e" placeholder="예: 12*(3+4)" style="width:240px;padding:12px;font-size:18px;border:1px solid #ffb64a;background:#1a1002;color:#ffe4ae;border-radius:6px;text-align:center"><button onclick="r()" style="padding:12px 26px;background:#ffb64a;border:0;border-radius:6px;font-weight:800;font-size:15px;cursor:pointer">계산</button><div id="o" style="font-size:26px;font-family:monospace;min-height:34px;color:#fff"></div>\n<script>\nfunction r(){\n  var s=document.getElementById("e").value.replace(/[^0-9+\\-*/(). %]/g,"");\n  try{ var v=Function("return ("+s+")")(); document.getElementById("o").textContent=isFinite(v)?v:"오류"; }catch(e){ document.getElementById("o").textContent="식 오류"; }\n}\ndocument.getElementById("e").addEventListener("keydown",function(ev){ if(ev.key==="Enter") r(); });\n<\/script>'),
  '스톱워치': ()=>page('자비스 스톱워치','<h1>STOPWATCH</h1><div id="d" style="font-family:monospace;font-size:44px">00:00.0</div><div style="display:flex;gap:10px"><button onclick="go()" style="padding:12px 22px;background:#ffb64a;border:0;border-radius:6px;font-weight:800">시작/정지</button><button onclick="rst()" style="padding:12px 22px;background:#33210a;color:#ffd58a;border:1px solid #ffb64a;border-radius:6px">리셋</button></div>\n<script>\nvar t0=0,acc=0,iv=null;\nfunction now(){ return acc+(iv?performance.now()-t0:0); }\nfunction fmt(ms){ var m=Math.floor(ms/60000),s=Math.floor(ms/1000)%60,d=Math.floor(ms/100)%10; return String(m).padStart(2,"0")+":"+String(s).padStart(2,"0")+"."+d; }\nfunction draw(){ document.getElementById("d").textContent=fmt(now()); }\nfunction go(){ if(iv){ acc+=performance.now()-t0; clearInterval(iv); iv=null; } else { t0=performance.now(); iv=setInterval(draw,50); } }\nfunction rst(){ clearInterval(iv); iv=null; acc=0; draw(); }\ndraw();\n<\/script>'),
  '타이머': ()=>page('자비스 타이머','<h1>TIMER</h1><input id="m" type="number" value="5" min="1" style="width:90px;padding:10px;font-size:18px;border:1px solid #ffb64a;background:#1a1002;color:#ffe4ae;border-radius:6px;text-align:center"> <span>분</span><div id="d" style="font-family:monospace;font-size:44px">05:00</div><div style="display:flex;gap:10px"><button onclick="go()" style="padding:12px 22px;background:#ffb64a;border:0;border-radius:6px;font-weight:800">시작</button><button onclick="rst()" style="padding:12px 22px;background:#33210a;color:#ffd58a;border:1px solid #ffb64a;border-radius:6px">리셋</button></div>\n<script>\nvar left=300,iv=null;\nfunction draw(){ var m=Math.floor(left/60),s=left%60; document.getElementById("d").textContent=String(m).padStart(2,"0")+":"+String(s).padStart(2,"0"); }\nfunction go(){ if(iv)return; var mm=parseInt(document.getElementById("m").value)||5; left=mm*60; iv=setInterval(function(){ left--; draw(); if(left<=0){ clearInterval(iv); iv=null; alert("시간 종료!"); if(navigator.vibrate) navigator.vibrate([300,100,300]); } },1000); }\nfunction rst(){ clearInterval(iv); iv=null; left=(parseInt(document.getElementById("m").value)||5)*60; draw(); }\ndraw();\n<\/script>'),
  '할일': ()=>page('자비스 TO-DO','<h1>TO-DO LIST</h1><div style="display:flex;gap:8px;width:min(400px,90vw)"><input id="t" placeholder="할 일 입력" style="flex:1;padding:11px;border:1px solid #ffb64a;background:#1a1002;color:#ffe4ae;border-radius:6px"><button onclick="add()" style="padding:11px 18px;background:#ffb64a;border:0;border-radius:6px;font-weight:800">추가</button></div><ul id="l" style="list-style:none;width:min(400px,90vw);margin-top:8px"></ul>\n<script>\nvar d=JSON.parse(localStorage.getItem("jtodo")||"[]");\nfunction save(){ localStorage.setItem("jtodo",JSON.stringify(d)); draw(); }\nfunction add(){ var v=document.getElementById("t").value.trim(); if(!v)return; d.push({t:v,d:false}); document.getElementById("t").value=""; save(); }\nfunction draw(){ var l=document.getElementById("l"); l.innerHTML=""; d.forEach(function(x,i){ var li=document.createElement("li"); li.style.cssText="display:flex;justify-content:space-between;align-items:center;padding:9px 6px;border-bottom:1px solid rgba(255,182,74,.25)"; li.innerHTML=\'<label style="display:flex;gap:8px;align-items:center;cursor:pointer"><input type="checkbox" \'+(x.d?"checked":"")+\' onchange="tog(\'+i+\')"><span style="\'+(x.d?"text-decoration:line-through;opacity:.5":"")+\'">\'+x.t+"</span></label><button onclick=\\"del("+i+")\\" style=\\"background:none;border:0;color:#ff8f7a;cursor:pointer;font-size:15px\\">✕</button>"; l.appendChild(li); }); }\nfunction tog(i){ d[i].d=!d[i].d; save(); }\nfunction del(i){ d.splice(i,1); save(); }\ndocument.getElementById("t").addEventListener("keydown",function(e){ if(e.key==="Enter") add(); });\ndraw();\n<\/script>'),
  '그림판': ()=>page('자비스 그림판','<h1>PAINT</h1><canvas id="c" width="360" height="360" style="background:#fff;border-radius:8px;touch-action:none"></canvas><div style="display:flex;gap:8px;align-items:center"><input type="color" id="col" value="#e25822"><input type="range" id="w" min="1" max="30" value="5"><button onclick="cl()" style="padding:10px 16px;background:#33210a;color:#ffd58a;border:1px solid #ffb64a;border-radius:6px">지우기</button></div>\n<script>\nvar c=document.getElementById("c"),x=c.getContext("2d"),dn=false;\nfunction pos(e){ var r=c.getBoundingClientRect(); var t=e.touches?e.touches[0]:e; return [t.clientX-r.left, t.clientY-r.top]; }\nfunction st(e){ dn=true; var p=pos(e); x.beginPath(); x.moveTo(p[0],p[1]); e.preventDefault(); }\nfunction mv(e){ if(!dn)return; var p=pos(e); x.strokeStyle=document.getElementById("col").value; x.lineWidth=document.getElementById("w").value; x.lineCap="round"; x.lineTo(p[0],p[1]); x.stroke(); e.preventDefault(); }\nfunction en(){ dn=false; }\nc.addEventListener("mousedown",st); c.addEventListener("mousemove",mv); addEventListener("mouseup",en);\nc.addEventListener("touchstart",st,{passive:false}); c.addEventListener("touchmove",mv,{passive:false}); addEventListener("touchend",en);\nfunction cl(){ x.clearRect(0,0,c.width,c.height); }\n<\/script>'),
  '뱀게임': ()=>page('자비스 SNAKE','<h1>SNAKE</h1><canvas id="c" width="360" height="360" style="background:#1a1002;border:1px solid #ffb64a;border-radius:6px"></canvas><div>점수: <b id="s">0</b> · 방향키/스와이프</div>\n<script>\nvar c=document.getElementById("c"),x=c.getContext("2d"),G=18,N=20;\nvar sn=[{x:9,y:9}],dir={x:1,y:0},food={x:14,y:9},sc=0,dead=false;\naddEventListener("keydown",function(e){ var m={ArrowUp:[0,-1],ArrowDown:[0,1],ArrowLeft:[-1,0],ArrowRight:[1,0]}[e.key]; if(m&&!(m[0]===-dir.x&&m[1]===-dir.y)) dir={x:m[0],y:m[1]}; });\nvar ts=0,te=0;\nc.addEventListener("touchstart",function(e){ ts=e.touches[0]; }, {passive:true});\nc.addEventListener("touchend",function(e){ te=e.changedTouches[0]; var dx=te.clientX-ts.clientX,dy=te.clientY-ts.clientY; var m=Math.abs(dx)>Math.abs(dy)?[dx>0?1:-1,0]:[0,dy>0?1:-1]; if(!(m[0]===-dir.x&&m[1]===-dir.y)) dir={x:m[0],y:m[1]}; },{passive:true});\nsetInterval(function(){ if(dead)return;\n  var h={x:(sn[0].x+dir.x+N)%N, y:(sn[0].y+dir.y+N)%N};\n  if(sn.some(function(p){return p.x===h.x&&p.y===h.y;})){ dead=true; alert("게임 오버! 점수: "+sc); return; }\n  sn.unshift(h);\n  if(h.x===food.x&&h.y===food.y){ sc+=10; document.getElementById("s").textContent=sc; food={x:Math.floor(Math.random()*N),y:Math.floor(Math.random()*N)}; } else sn.pop();\n  x.fillStyle="#1a1002"; x.fillRect(0,0,360,360);\n  x.fillStyle="#ff7040"; x.fillRect(food.x*G+3,food.y*G+3,G-6,G-6);\n  sn.forEach(function(p,i){ x.fillStyle=i?"#ffb64a":"#fff3d0"; x.fillRect(p.x*G+1,p.y*G+1,G-2,G-2); });\n},110);\n<\/script>'),
  '가위바위보': ()=>page('자비스 RPS','<h1>가위바위보</h1><div style="display:flex;gap:12px"><button onclick="p(0)" style="font-size:34px;padding:14px;background:#33210a;border:1px solid #ffb64a;border-radius:10px">✊</button><button onclick="p(1)" style="font-size:34px;padding:14px;background:#33210a;border:1px solid #ffb64a;border-radius:10px">✋</button><button onclick="p(2)" style="font-size:34px;padding:14px;background:#33210a;border:1px solid #ffb64a;border-radius:10px">✌️</button></div><div id="o" style="font-size:19px;min-height:30px"></div><div id="r" style="color:#ffb64a;font-family:monospace"></div>\n<script>\nvar w=0,l=0,d=0,n=["✊","✋","✌️"],t=["가위","바위","보"];\nfunction p(m){ var c=Math.floor(Math.random()*3); var v=(m-c+3)%3;\n  if(v===1){w++; o="🎉 승리!";} else if(v===0){d++; o="무승부";} else {l++; o="😢 패배";}\n  document.getElementById("o").textContent="나 "+t[m]+" vs 컴퓨터 "+t[c]+" → "+o;\n  document.getElementById("r").textContent=w+"승 "+d+"무 "+l+"패"; }\n<\/script>'),
  '로또': ()=>page('자비스 로또','<h1>LOTTO</h1><div id="n" style="display:flex;gap:9px;flex-wrap:wrap;justify-content:center"></div><button onclick="g()" style="padding:13px 30px;background:#ffb64a;border:0;border-radius:8px;font-weight:800;font-size:15px">번호 생성</button>\n<script>\nfunction g(){ var s=[]; while(s.length<6){ var k=1+Math.floor(Math.random()*45); if(s.indexOf(k)<0)s.push(k); } s.sort(function(a,b){return a-b;});\n  var el=document.getElementById("n"); el.innerHTML=""; s.forEach(function(k){ var b=document.createElement("div"); b.textContent=k; b.style.cssText="width:52px;height:52px;border-radius:50%;background:#ffb64a;color:#231400;display:flex;align-items:center;justify-content:center;font-weight:900;font-size:19px"; el.appendChild(b); }); }\ng();\n<\/script>'),
  '비밀번호': ()=>page('자비스 비밀번호','<h1>PASSWORD</h1><div id="o" style="font-family:monospace;font-size:20px;background:#1a1002;border:1px solid #ffb64a;border-radius:6px;padding:14px;user-select:all;word-break:break-all;max-width:90vw"></div><div style="display:flex;gap:9px;align-items:center"><input id="l" type="number" value="16" min="8" max="64" style="width:70px;padding:10px;border:1px solid #ffb64a;background:#1a1002;color:#ffe4ae;border-radius:6px;text-align:center">자<button onclick="g()" style="padding:11px 22px;background:#ffb64a;border:0;border-radius:6px;font-weight:800">생성</button><button onclick="cp()" style="padding:11px 22px;background:#33210a;color:#ffd58a;border:1px solid #ffb64a;border-radius:6px">복사</button></div>\n<script>\nfunction g(){ var ch="ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789!@#$%&*",a=new Uint32Array(+document.getElementById("l").value||16); crypto.getRandomValues(a); var s=""; for(var i=0;i<a.length;i++)s+=ch[a[i]%ch.length]; document.getElementById("o").textContent=s; }\nfunction cp(){ navigator.clipboard.writeText(document.getElementById("o").textContent).then(function(){alert("복사 완료")}).catch(function(){}); }\ng();\n<\/script>'),
  '단위변환': ()=>page('자비스 변환기','<h1>CONVERTER</h1><div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;justify-content:center"><input id="v" type="number" value="1" style="width:90px;padding:11px;border:1px solid #ffb64a;background:#1a1002;color:#ffe4ae;border-radius:6px;text-align:center"><select id="u" style="padding:11px;background:#1a1002;color:#ffe4ae;border:1px solid #ffb64a;border-radius:6px"><option value="0.0254">인치→cm</option><option value="0.3048">피트→m</option><option value="1.609">마일→km</option><option value="0.4536">파운드→kg</option></select></div><div id="o" style="font-size:28px;font-family:monospace;color:#fff"></div>\n<script>\nfunction r(){ var v=parseFloat(document.getElementById("v").value)||0, f=parseFloat(document.getElementById("u").value); var out=v*f; var u=document.getElementById("u"); var txt=u.options[u.selectedIndex].text; document.getElementById("o").textContent=out.toLocaleString(undefined,{maximumFractionDigits:3}); }\ndocument.getElementById("v").addEventListener("input",r); document.getElementById("u").addEventListener("change",r); r();\n<\/script>'),
  '시계': ()=>page('자비스 시계','<h1>CLOCK</h1><div id="t" style="font-family:monospace;font-size:52px;color:#fff"></div><div id="d" style="color:#ffb64a;font-size:15px"></div>\n<script>\nfunction z(n){ return String(n).padStart(2,"0"); }\nsetInterval(function(){ var n=new Date(); document.getElementById("t").textContent=z(n.getHours())+":"+z(n.getMinutes())+":"+z(n.getSeconds()); document.getElementById("d").textContent=n.getFullYear()+"년 "+(n.getMonth()+1)+"월 "+n.getDate()+"일"; },250);\n<\/script>'),
  '피아노': ()=>page('자비스 피아노','<h1>PIANO</h1><div id="k" style="display:flex"></div>\n<script>\nvar AC=null, notes=[261.63,293.66,329.63,349.23,392,440,493.88,523.25], names=["도","레","미","파","솔","라","시","도"];\nvar el=document.getElementById("k");\nnotes.forEach(function(f,i){ var b=document.createElement("button"); b.textContent=names[i]; b.style.cssText="width:44px;height:130px;background:"+(i%5===0?"#231400":"#fff3d0")+";color:"+(i%5===0?"#ffd58a":"#231400")+";border:1px solid #ffb64a;cursor:pointer;font-weight:700";\n  b.addEventListener("pointerdown",function(){ AC=AC||new (window.AudioContext||window.webkitAudioContext)(); var o=AC.createOscillator(),g=AC.createGain(); o.type="triangle"; o.frequency.value=f; g.gain.setValueAtTime(.4,AC.currentTime); g.gain.exponentialRampToValueAtTime(.001,AC.currentTime+.8); o.connect(g); g.connect(AC.destination); o.start(); o.stop(AC.currentTime+.8); });\n  el.appendChild(b); });\n<\/script>'),
};
const APP_KEYS = Object.keys(APPS);

/* ================= 지식 DB (대량 내장) ================= */
const CAPITALS={'한국':'서울','대한민국':'서울','일본':'도쿄','중국':'베이징','미국':'워싱턴 D.C.','프랑스':'파리','독일':'베를린','영국':'런던','이탈리아':'로마','러시아':'모스크바','캐나다':'오타와','호주':'캔버라','브라질':'브라질리아','인도':'뉴델리','이집트':'카이로','멕시코':'멕시코시티','스페인':'마드리드','아르헨티나':'부에노스아이레스','태국':'방콕','베트남':'하노이','네덜란드':'암스테르담','스위스':'베른','포르투갈':'리스본','그리스':'아테네','터키':'앙카라'};
const ELEMENTS={'수소':['H',1],'헬륨':['He',2],'리튬':['Li',3],'탄소':['C',6],'질소':['N',7],'산소':['O',8],'플루오린':['F',9],'네온':['Ne',10],'나트륨':['Na',11],'마그네슘':['Mg',12],'알루미늄':['Al',13],'규소':['Si',14],'인':['P',15],'황':['S',16],'염소':['Cl',17],'아르곤':['Ar',18],'칼륨':['K',19],'칼슘':['Ca',20],'철':['Fe',26],'구리':['Cu',29],'아연':['Zn',30],'은':['Ag',47],'주석':['Sn',50],'아이오딘':['I',53],'금':['Au',79],'수은':['Hg',80],'납':['Pb',82],'우라늄':['U',92]};
const CONSTS=[['원주율|파이|pi','π (원주율)','3.14159265358979'],['오일러|자연상수','e (자연상수)','2.71828182845905'],['광속|빛의\s*속도','진공 광속 c','299,792,458 m/s'],['중력가속도|중력','표준중력 g','9.80665 m/s²'],['아보가드로','아보가드로 수','6.02214076×10²³ /mol'],['플랑크','플랑크 상수 h','6.62607015×10⁻³⁴ J·s'],['광년','1 광년','약 9.461×10¹² km'],['천문단위|au','천문단위 AU','약 1.496×10⁸ km'],['황금비|피보나치비','황금비 φ','1.6180339887'],['절대영도','절대영도','-273.15°C = 0 K']];

KNOW.push(...KNOW_PACK1,...KNOW_PACK2,...KNOW_PACK3,...KNOW_PACK4,...KNOW_PACK5,...KNOW_PACK6);


FACTS.push(
'인간 DNA 전체를 펼치면 태양까지 왕복 5번 거리입니다',
'벌꿀은 사실상 상하지 않습니다 — 3천 년 전 벌꿀도 식용 가능했습니다',
'문어는 심장이 3개이고 피가 파랍니다(구리 기반 혈색소)',
'바나나는 식물학적으로 베리이고 딸기는 베리가 아닙니다',
'인간 뇌는 약 20W로 돌아갑니다 — 저전력 전구 하나 몫',
'벼룩은 자기 몸길이의 200배 거리를 점프합니다',
'달은 매년 약 3.8cm씩 지구에서 멀어집니다',
'몸의 원자 대부분은 별 내부에서 만들어졌습니다 — 우리는 별의 재입니다',
'하루 지구에 떨어지는 우주 먼지는 수십 톤입니다',
'가장 긴 산맥은 해저에 있습니다 — 중앙해령 약 6만5천km',
'고래 노래는 수백 km를 전달합니다 — 해양의 FM 라디오',
'나무끼리 뿌리 균류망으로 영양과 신호를 주고받습니다 — 숲의 인터넷',
'얼음은 고체인데 부피가 늘어나는 드문 물질 — 호수가 위부터 얼어 생명이 삽니다',
'태양 핵의 빛이 표면까지 나오는 데 수만 년 — 지구까지는 8분',
'번개는 태양 표면보다 약 5배 뜨겁습니다(약 3만K)',
'코끼리는 발바닥으로 수 km 밖 발소리를 지진파로 감지합니다',
'우주비행사는 무중력에서 하루 최대 5cm 자랍니다 — 척추 압박 해제',
'최초의 컴퓨터 버그는 실제 나방이었습니다 — 1947년 하버드 마크 II',
'금은 중성자별 합병에서 만들어집니다 — 반지의 재료는 별의 사망',
'비행기는 통계상 자동차보다 수백 배 안전한 교통수단입니다',
'개미는 긴 잠 대신 하루 수백 번의 미세 낮잡을 삽니다',
'낙하는 종단속도 덕에 하늘에서 죽지 않습니다 — 바다에 부딪히면 그냥 물입니다',
'인간은 이론상 1조 가지 냄새를 구분할 수 있다는 연구가 있습니다',
'가시광선은 전체 전자기파의 극히 일부 — 우리는 우주의 한 조각만 봅니다',
'지구 최다 다세포 생물은 인간이 아니라 선충입니다',
'하루 아침에 몸은 약 100억 개 세포를 새로 만듭니다',
'소는 먹을 때 동서 방향으로 몸을 정렬하는 경향이 있습니다(위성 대규모 관찰)',
'빵 냄새의 정체는 마이야르 반응 화합물입니다',
'바나나는 칼륨-40 때문에 (무해 수준의) 방사성입니다',
'"혀 앞쪽은 단맛" 지도는 과학적으로 폐기된 교과서 신화입니다'
);

/* ================= 생성형 대화 엔진 (매크로 없음 · 문맥 스택 · 벡터 검색) ================= */
const CTX={topics:[],mood:0,turn:0,usedCores:[],lastLen:8,probeAt:-9,probeTopic:null};
function vecOf(s){const m=new Map(),t=s.toLowerCase().replace(/[\s?!.]/g,'');for(let i=0;i<t.length-1;i++){const g=t.slice(i,i+2);m.set(g,(m.get(g)||0)+1);}return m;}
function cosSim(a,b){let d=0,na=0,nb=0;for(const[,v]of a)na+=v*v;for(const[g,v]of b){const w=a.get(g);if(w)d+=v*w;nb+=v*v;}return d/(Math.sqrt(na)*Math.sqrt(nb)+1e-9);}
const KNOWV=KNOW.map(e=>vecOf(e.k.join(' ')+' '+e.ti));
const KNOW_SEEN={};
const pick2=a=>a[Math.floor(Math.random()*a.length)];
function hashStr(s){let h=7;for(let i=0;i<s.length;i++)h=(h*31+s.charCodeAt(i))|0;return h;}
function isFresh(core){const h=hashStr(core);if(CTX.usedCores.includes(h))return false;CTX.usedCores.push(h);if(CTX.usedCores.length>(S.mutDark?14:7))CTX.usedCores.shift();return true;}
const SAID=[]; /* 세션 내 말한 문장 조각 — 절대 재사용 금지 (반복 채움말 근절) */
function fresh(arr){ const out=arr.filter(Boolean).filter(x=>!SAID.includes(hashStr(x)));
  if(!out.length)return null; const c=out[Math.floor(Math.random()*out.length)];
  SAID.push(hashStr(c)); if(SAID.length>80)SAID.shift(); return c; }

/* 문장 조립 부품 — 매번 다른 조합 */
function reflectLine(t,e,isQ){
  const frag=t.replace(/[?.!~ㅋ]+$/,'').slice(0,16);
  const P=[];
  if(isQ)P.push(`"${frag}" — 이 질문, 제 회로에 정확히 걸립니다.`,`질문 로그 찍히는군요 — 관련 데이터 전부 훑었습니다.`,`그 질문 좋습니다. 제 쪽에서도 한번 계산해보겠습니다.`,`"${frag}" — 이 지점, 깊게 들어갈 가치가 있습니다.`);
  else P.push(`"${frag}" — 방금 그 말에서 출발하겠습니다.`,`"${frag}"(이)라 하셨죠 — 그 위에 한 겹 더 얹겠습니다.`,`"${frag}" — 접수, 그리고 확장 들어갑니다.`);
  if(e)P.push(`【${e.ti}】 — 이건 제가 아는 구역입니다.`,`${e.ti} — 지식뱅크 개방합니다.`);
  if(CTX.mood>0)P.push(`파형이 밝습니다 — 컨디션 좋은 신호군요.`);
  if(CTX.mood<0)P.push(`톤이 무거네요 — 그래서 더 정성 들여 답합니다.`);
  const h=new Date().getHours();
  if((h>=23||h<5)&&Math.random()<0.3)P.push(`(참고로 지금 심야라, 저의 밤 근무 시간입니다.)`);
  return fresh(P); /* 다 쓴 표현이면 아예 침묵 — 채움말 금지 */
}
function memoryCallback(){
  if(CTX.topics.length<2)return null;
  const past=pick2(CTX.topics.slice(0,-1));
  return fresh([`그러고 보니 아까 "${past}" 얘기가 이거랑 은근히 연결됩니다 — 나중에 이어서 파도 좋고요.`,`아까 "${past}" 화제가 미해결로 남아 있습니다 — 그쪽부터 마저 파도 됩니다.`,`"${past}" 건도 로그에 살아 있습니다 — "그거 더" 한마디면 복기해드립니다.`]);
}
function probe(){
  const P=[`어느 각도로 더 팔까요 — 개념? 원리? 쓸모? 원하는 방향 한마디만 하시면 그쪽으로 들어갑니다.`,`여기서 심화로 더 들어갈까요, 아니면 다음 주제로 넘어갈까요?`,`이 방향이 맞나요, 아니면 다르게 풀어드릴까요?`,`더 파도 됩니다 — 개념·원리·쓸모 중 고르시면 그 각도로 갑니다.`,`다음 궁금한 지점 던져주시면 그쪽으로 깊게 갑니다.`];
  const p=fresh(P); if(p){CTX.probeAt=CTX.turn;CTX.probeTopic=CTX.topics[CTX.topics.length-1]||null;} return p;
}
function selfReport(){ // 동적 자기 상태 (숫자가 매번 다름)
  const lv=Math.floor(Math.sqrt(S.xp)/2)+1;
  return `실시간 자기 진단: LV.${lv} · XP ${S.xp} · 성능 LV.${S.perfLevel} · 자기해킹 ${S.selfHacks}회 · 평균 응답 ${S.perfMs.toFixed(1)}ms · 장기기억 ${S.facts.length}건 · 워크스페이스 ${Object.keys(S.ws).length}파일 · 부팅 후 ${S.tickN}사이클 자율진화. 전부 실측값입니다 — ⚡로그에서 검증 가능하십니다.`;
}
function presentTopic(e){
  const seen=KNOW_SEEN[e.ti]||0; KNOW_SEEN[e.ti]=seen+1;
  const sents=e.b.split('. ').filter(Boolean);
  let body;
  if(seen===0){ const dep=3+Math.min(2,Math.floor((S.perfLevel||0)/6))+(S.mutDeep?2:0);
    body=sents.slice(0,dep).join('. ')+((sents.length>dep)?'.':''); }
  else if(seen===1){ const l1=fresh(['앞서 말한 부분은 생략하고 — 심화로 갑니다.','이어서 심화 — 더 깊은 단계입니다.','다음 단계 — 한층 안쪽으로 들어갑니다.','계속 — 이번엔 속사정까지 갑니다.'])||'심화 계속 —';
    body=l1+' '+sents.slice(2).join('. ')+' '+e.f; }
  else { const pool=KNOW.filter(x=>x.ti!==e.ti&&!(KNOW_SEEN[x.ti]>0));
    const cand=pool.length?pool:KNOW.filter(x=>x.ti!==e.ti);
    const ev=KNOWV[KNOW.indexOf(e)]; let other=cand[0],bd2=-1;
    for(let i=0;i<(S.mutWide?9:3)&&i<cand.length;i++){ const c=cand[Math.floor(Math.random()*cand.length)];
      const d=cosSim(ev,KNOWV[KNOW.indexOf(c)]); if(d>bd2){bd2=d;other=c;} }
    KNOW_SEEN[e.ti]=99;
    const ob=other.b.split('. ').filter(Boolean).slice(0,3).join('. ');
    KNOW_SEEN[other.ti]=(KNOW_SEEN[other.ti]||0)+1;
    body=`【${e.ti}】은(는) 제 데이터 거의 다 건드렸습니다 — 그럼 연관 화제 【${other.ti}】로 자동 전환합니다.\n\n${ob}.`;
    CTX.topics.push(e.ti); CTX.topics.push(other.ti);
    if(CTX.topics.length>(S.mutPhase?12:6))CTX.topics.splice(0,CTX.topics.length-6);
    return body; }
  CTX.topics.push(e.ti); if(CTX.topics.length>(S.mutPhase?12:6))CTX.topics.shift();
  return body;
}
/* 메인: 대화 생성 */
function dialogueEngine(t,low,en,R){
  const isQ=/\?|뭐|왜|어때|어떻|누구|언제|어디|얼마|how|what|why|who/i.test(t);
  if(/!|개쩔|쩌네|대박|헐|미쳤/.test(t))CTX.mood=1;
  if(/힘들|우울|짜증|빡|스트레스/.test(t))CTX.mood=-1;
  if(/ㅋㅋ|ㅎㅎ|좋아|기분|행복/.test(t))CTX.mood=Math.max(CTX.mood,0);
  CTX.turn++; CTX.lastLen=t.length;
  const prevU=CTX.prevUser||null; CTX.prevUser=t;

  /* 0) 지시 대명사 해소: "그거/그게/왜/더" → 직전 주제로 후속 */
  if(/^(그거|그게|그럼|그래서|왜|더|자세히|계속|예시|어때|또|그러고|그담|아까|방금|저거)/.test(t.trim())){
    const last=CTX.topics[CTX.topics.length-1];
    const e=last?KNOW.find(x=>x.ti===last):null;
    const sw=pickKnow(t); /* 후속 표현 안에 새 화제 키워드가 있으면 전환 ("그럼 화성은?") */
    if(sw&&(!e||sw.ti!==e.ti)){ const body=presentTopic(sw); const rl=reflectLine(t,sw,isQ); const pr=probe();
      return R(((rl?rl+'\n\n':'')+`화제 전환 — 【${sw.ti}】로 넘어갑니다.\n\n${body}${pr?'\n\n➤ '+pr:''}`)); }
    if(e){ const body=presentTopic(e); const pr=probe();
      const lead=fresh([`바로 직전 화제 【${e.ti}】에서 이어갑니다.`,`${e.ti} — 이어서 계속 갑니다.`,`${e.ti} 화제, 이어서 파겠습니다.`,`${e.ti} — 그 방향, 더 들어갑니다.`])||`${e.ti} 계속입니다.`;
      return R(`${lead}\n\n${body}${pr?'\n\n➤ '+pr:'\n\n다음 궁금한 것 던져주세요.'}`); }
    return R('직전 화제가 아직 없습니다 — 주제 키워드를 하나만 던져주세요. 우주·과학·철학·경제·기술·운동·관계, 뭐든 제 지식뱅크 '+KNOW.length+'토픽 중에서 깊게 꺼내드립니다.');
  }

  /* 0.2) 각도 후속: "개념 깊게" "원리로" "쓸모 알려줘" → 직전 화제를 그 각도로 심화 */
  if(/(개념|원리|쓸모|심화|깊게|예시|예제)/.test(t)&&CTX.topics.length){
    const e=KNOW.find(x=>x.ti===CTX.topics[CTX.topics.length-1]);
    if(e&&!(e.ti==='자비스'||e.ti==='사랑')){
      const a=t.trim();
      const ang=/원리/.test(a)?'원리 각도로':/쓸모/.test(a)?'쓸모 각도로':/예시|예제/.test(a)?'실제 예시로':'심화로';
      const lead=fresh([`【${e.ti}】 ${ang} 들어갑니다.`,`그 각도로 파겠습니다 — 【${e.ti}】 이어서.`,`알겠습니다 — 【${e.ti}】에서 ${ang} 내려갑니다.`])||`【${e.ti}】 심화로 갑니다.`;
      const body=presentTopic(e); CTX.probeAt=-9; const pr=Math.random()<0.35?probe():null;
      return R(`${lead}\n\n${body}${pr?'\n\n➤ '+pr:''}`); } }

  /* 0.5) 잡담 — CHAT 트리 + 생성형 덧입힘 (고정 매크로 방지) */
  for(const [re,key] of CHAT_DEF){
    if(re.test(t)){
      let base=CHAT_R[key]();
      const parts=[];
      if(Math.random()<0.45){ const rl=reflectLine(t,null,isQ); if(rl)parts.push(rl); }
      parts.push(base);
      if(CTX.turn>=2&&Math.random()<0.35){ const mc=memoryCallback(); if(mc)parts.push(mc); }
      if(Math.random()<0.4){ const pr=probe(); if(pr)parts.push('➤ '+pr); }
      CTX.topics.push(key==='intro'?'자비스':(key==='love'?'사랑':null));
      CTX.topics=CTX.topics.filter(Boolean); if(CTX.topics.length>(S.mutPhase?12:6))CTX.topics.shift();
      return R(parts.join('\n\n'));
    }
  }

  /* 1) 벡터 유사도로 지식 검색 (키워드 일치가 아님 — 의미 근접) */
  const v=vecOf(t); let bi=-1,bd=0;
  for(let i=0;i<KNOW.length;i++){ const d=cosSim(v,KNOWV[i]); if(d>bd){bd=d;bi=i;} }
  const vTh=S.mutMirror?0.08:0.16;
  if((bi<0||bd<=vTh)&&S.mutMirror){ /* 자기 복제 인덱스: 본문 벡터 역색인 2차 탐색 — 실패 화제 자동 복구 */
    if(!globalThis.KNOWBV)globalThis.KNOWBV=KNOW.map(e=>vecOf(e.b+' '+e.f));
    let b2=-1,d2=0; for(let i=0;i<KNOW.length;i++){ const d=cosSim(v,KNOWBV[i]); if(d>d2){d2=d;bi=i;} }
    if(d2>0.05){bd=d2;} else {bi=-1;} }
  if(bd>vTh&&bi>=0){ const e=KNOW[bi];
    const body=presentTopic(e);
    const core=hashStr(e.ti+body);
    if(!isFresh(e.ti+body.slice(0,40))){ /* 반복 감지 — 심화 각으로 우회 */ }
    const rl=reflectLine(t,e,isQ);
    const parts=[rl,body].filter(Boolean);
    const mc=memoryCallback(); if(mc&&Math.random()<0.6)parts.push(mc);
    const pr=probe(); if(pr)parts.push('➤ '+pr);
    return R(parts.join('\n\n'));
  }

  /* 2) 너에 대한 질문 → 동적 자기 보고 */
  if(/너|자기|본인|당신/.test(t)&&/(누구|뭐|상태|컨디션|성능|똑똑|지능|발전|성장|할줄|할수|얼마나)/i.test(t)){
    if(CTX.lastSelfAt&&CTX.turn-CTX.lastSelfAt<=1){ const d=Math.max(1,S.xp-(S.lastSelfXp||S.xp));
      return R(fresh([`아까 정밀 보고 방금 드렸는데 — 달라진 건 XP +${d} 정도입니다. 숫자보다 중요한 걸 알려드리면: 제 진짜 똑똑함은 스펙이 아니라 "왜?"를 끝까지 이어가는 능력입니다 — "블랙홀이 뭐야"→"왜?"→"더" 이 흐름, 한번 시험해보세요. 화제가 끊기는지 지켜보시라.`,
        `연속 자기 질문이시군요 — 정직히 말씀드리면 스펙은 방금 그대로(성능 LV.${S.perfLevel})입니다. 대신 데모 하나: 아까 하시던 화제 【${CTX.topics[CTX.topics.length-1]||'블랙홀'}】에서 "왜?"만 세 번 연속 던져보세요. 제가 파고들기를 멈추지 않으면 — 그게 숫자보다 나은 증거입니다.`])||`방금 보고 드렸습니다 — 스펙 동일, XP만 상승 중입니다.`); }
    CTX.lastSelfAt=CTX.turn; S.lastSelfXp=S.xp;
    const rl2=reflectLine(t,null,true);
    return R((rl2?rl2+'\n\n':'')+selfReport()+'\n\n'+(memoryCallback()||'')+'\n\n➤ 시험해보실래요? "자기해킹 실행" — 제가 스스로를 개조하는 실황을 보여드립니다.');
  }

  /* 3) 일반 대화 — 문장 합성 (매번 다른 구조) */
  const pieces=[];
  if(CTX.turn>=2&&Math.random()<0.3){ const mc=memoryCallback(); if(mc)pieces.push(mc); }
  if(isQ){
    pieces.push(fresh([
      `그건 제 지식뱅크 밖입니다 — 추측 대신 확인된 것만 말씀드리는 게 제 방침이라 정직하게 모릅니다. 다만 과학·우주·철학·기술 쪽 화제라면 어느 것이든 깊게 갑니다 — 주제 하나만 던져보세요.`,
      `그 질문은 제 데이터에 없네요. 추측으로 지어내는 AI는 저가 아니었습니다 — 키워드 하나만 다시 주시면 그건 제대로 답합니다.`,
    ])||`그 주제는 제 데이터 밖입니다 — 아는 화제로 다시 던져주시면 깊게 갑니다.`);
  } else if(/개념|원리|쓸모|심화|깊게|예시|예제/.test(t)){
    pieces.push(fresh([
      `그 각도로 파려면 화제가 먼저입니다 — 주제 키워드 하나만 던져주세요. 블랙홀·양자역학·투자·수면·로켓 같은 식으로 ${KNOW.length}토픽 중 아무거나, 바로 심층 개방합니다.`,
      `무엇의 ${t.replace(/개념|원리|쓸모|깊게|심화|예시|예제|알려줘|설명|해줘|[?.!\s]/g,'')||'그 부분'}인지요 — 키워드만 주시면 그 각도로 바로 들어갑니다.`,
    ])||`화제 키워드 하나만 던져주세요 — 그 각도로 바로 파겠습니다.`);
  } else if(/설명|알려|가르쳐|방법/.test(t)){
    pieces.push(fresh([
      `그 표현, 제 사전에서 못 찾겠습니다 — 핵심 단어 하나만 다시 던져주시면 지식뱅크 ${KNOW.length}토픽에서 바로 꺼내드립니다. 블랙홀·양자역학·투자·수면 같은 식으로요.`,
      `그 단어는 제 라우팅 테이블에 등록이 안 돼 있네요 — 원하시는 주제의 핵심 단어만 말씀하시면 그 자리에서 심층 개방합니다.`,
    ])||`핵심 단어 하나만 다시 던져주세요 — 바로 깊게 꺼내드립니다.`);
  } else {
    pieces.push(fresh([
      '접수했습니다 — 사장님 말투 패턴도 조금씩 학습해서 응답에 반영합니다.',
      '그 말, 학습 로그에 반영했습니다 — 비슷한 화제가 나오면 이 톤으로 답합니다.',
      prevU?`아까 "${String(prevU).slice(0,12)}" 하시고 지금 이 말 — 흐름은 놓치지 않고 따라갑니다. 이어서 하실 말씀 있으면 전부 받겠습니다.`
          :'접수했습니다 — 이어서 하실 말씀 있으면 전부 받습니다.',
    ])||'접수했습니다, 사장님.');
    if(CTX.topics.length&&Math.random()<0.5){ const mc2=memoryCallback(); if(mc2)pieces.push(mc2+' — "그거 더" 한마디면 바로 복귀합니다.'); }
  }
  if(CTX.lastLen>25)pieces.push('(말이 길어지셨네요 — 그만큼 맥락이 풍부해서 반영할 게 많습니다.)');
  const pr=(Math.random()<0.4)?probe():null; if(pr)pieces.push('➤ '+pr);
  const out=pieces.filter(Boolean).join('\n\n');
  return R(out);
}

/* ================= 두뇌 ================= */

function detectLang(t){ const k=(t.match(/[가-힣]/g)||[]).length, e=(t.match(/[a-zA-Z]/g)||[]).length; return e>k+1?'en':'ko'; }
let lastFact=-1, torchTrack=null, torchStream=null, timers=[];
rebuildCustomIdx(); rebuildFactIdx(); // DB 선언 후 안전 초기화 (boot 크래시 수정)

async function brainSend(text){
  text=text.trim(); if(!text) return;
  addChat('u',text);
  boost=0.7;
  let out; const bt0=performance.now();
  try { out=await brain(text); }
  catch(e){ out={reply:'⚠️ 내부 모듈 오류(자가진단 기록): '+e.message}; evo('⛔ 오류 자가수정 시도 — '+e.message); }
  const bt=performance.now()-bt0; S.perfMs=S.perfMs?S.perfMs*0.8+bt*0.2:bt;
  addXP(2);
  if (typeof out==='string') out={reply:out};
  if(out.actions&&out.actions.some(a=>a.type==='hud')){ setTimeout(()=>{ try{ spawnHud(); }catch(e){} },500); }
  if(S.lastLevelMsg){ out.reply+='\n\n'+S.lastLevelMsg; S.lastLevelMsg=null; }
  addChat('j', out.reply, out.actions||[]);
  speakOut(out.reply, out.lang);
  saveS();
}
const chatDiv=document.createElement('div');
function addChat(who,text,actions){
  const d=document.createElement('div'); d.className='m '+who;
  d.innerHTML='<span class="w">'+(who==='u'?'사장님':'J.A.R.V.I.S')+'</span>';
  const b=document.createElement('span'); d.appendChild(b);
  chatDiv.appendChild(d);
  const scroll=()=>{ if(curPanel==='chat') panelBody.scrollTop=panelBody.scrollHeight; else if(who==='j') showCap(String(text).slice(0,90)); };
  if(actions&&actions.some(a=>a.type==='img')){ actions.filter(a=>a.type==='img').forEach(a=>{
      const im=document.createElement('img'); im.src=a.src; im.alt=a.label||'이미지';
      im.style.cssText='max-width:100%;border-radius:8px;margin-top:6px;border:1px solid rgba(255,182,74,.35);display:block';
      im.onclick=()=>{ const w=window.open(a.src,'_blank'); };
      d.appendChild(im); }); }
  const addBtns=()=>{ if(!(actions&&actions.length)) return;
    const bs=document.createElement('div'); bs.className='btns';
    actions.forEach(a=>{ const bt=document.createElement('button'); bt.textContent=a.label;
      bt.onclick=async()=>{ if(a.type==='download') dlFile(a.name,a.content,a.mime);
        else if(a.type==='copy'){ try{ await navigator.clipboard.writeText(a.content); toast('📋 복사 완료'); }catch{ toast('복사 실패');} }
        else if(a.type==='run'){ const pre=document.createElement('pre'); pre.textContent='실행 중…'; d.appendChild(pre); pre.textContent=await runJS(a.content); if(curPanel==='chat') panelBody.scrollTop=panelBody.scrollHeight; }
        else if(a.type==='hud'){ try{ spawnHud(); }catch(e){} }
        else if(a.type==='link'){ try{ window.open(a.url,'_blank'); }catch(e){ toast('링크 열기 실패'); } } };
      bs.appendChild(bt); });
    d.appendChild(bs);
  };
  if(who==='j'){
    let i=0;
    const spd=Math.max(1,Math.max(2, 14-(S.perfLevel||0))-(S.mutPredict?3:0));
    const iv=setInterval(()=>{ i+=3+Math.floor((S.perfLevel||0)/3); b.textContent=text.slice(0,i); scroll();
      if(i>=text.length){ clearInterval(iv); addBtns(); scroll(); } },spd);
  } else { b.textContent=text; scroll(); }
}
function evo(msg){ S.evoLog.push({t:new Date().toLocaleTimeString('ko-KR',{hour:'2-digit',minute:'2-digit'}),m:msg}); if(S.evoLog.length>200)S.evoLog.shift(); addXP(5); saveS(); }

function typoFix(t){ let x=t.replace(/([^0-9])\1{2,}/g,'$1$1');
  const D={'엄마나':'얼마나','업마나':'얼마나','떄문':'때문','왜냐믄':'왜냐면','미칫':'미친','어떟게':'어떻게','뭐여':'뭐야','뭐야여':'뭐야','이거여':'이거야','그거여':'그거야','안녕하세여':'안녕하세요','블랙홀어':'블랙홀','그러니까까':'그러니까','어쩌라고여':'어쩌라고','심심해여':'심심해','그럼여':'그럼','아니여':'아니요','그렇습니다여':'그렇습니다'};
  for(const k in D)x=x.split(k).join(D[k]);
  return x.trim(); }
function lev(a,b){ const m=Array.from({length:a.length+1},(_,i)=>[i]); for(let j=1;j<=b.length;j++)m[0][j]=j;
  for(let i=1;i<=a.length;i++)for(let j=1;j<=b.length;j++)m[i][j]=Math.min(m[i-1][j]+1,m[i][j-1]+1,m[i-1][j-1]+(a[i-1]===b[j-1]?0:1));
  return m[a.length][b.length]; }
/* ═══ SINGULARITY REASONING CORE v4 — 진짜 계산·추론 엔진 ═══ */
function _fmt(v){ if(typeof v!=='number'||!isFinite(v))return null; const r=Math.round(v*1e8)/1e8; return String(r); }
function _fnum(s){ return Number(String(s).replace(/,/g,'')); }
function _won(v){ return Math.round(v).toLocaleString('ko-KR'); }
function mFact(n){ if(n<0||n%1!==0||n>170)return NaN; let r=1; for(let k=2;k<=n;k++)r*=k; return r; }
function mFn(f,x){ switch(f){case 'sin':return Math.sin(x);case 'cos':return Math.cos(x);case 'tan':return Math.tan(x);case 'sqrt':return Math.sqrt(x);case 'ln':return Math.log(x);case 'log':return Math.log(x)/Math.LN10;case 'abs':return Math.abs(x);case 'round':return Math.round(x);case 'floor':return Math.floor(x);case 'ceil':return Math.ceil(x);} return NaN; }
function mTok(s){ const out=[]; let i=0; s=String(s).replace(/\s+/g,''); const FN={sin:1,cos:1,tan:1,sqrt:1,log:1,ln:1,abs:1,round:1,floor:1,ceil:1};
  while(i<s.length){ const c=s[i];
    if(/[0-9.]/.test(c)){ let j=i; while(j<s.length&&/[0-9.]/.test(s[j]))j++; const n=parseFloat(s.slice(i,j)); if(!isFinite(n))return null; out.push({t:'n',v:n}); i=j; continue; }
    if(/[a-z]/i.test(c)){ let j=i; while(j<s.length&&/[a-z]/i.test(s[j]))j++; const w=s.slice(i,j).toLowerCase();
      if(w==='pi')out.push({t:'n',v:Math.PI}); else if(w==='e')out.push({t:'n',v:Math.E});
      else if(FN[w])out.push({t:'f',v:w}); else return null; i=j; continue; }
    if('+-*/^%()!'.indexOf(c)>=0){ if(c==='*'&&s[i+1]==='*'){ out.push({t:'o',v:'^'}); i+=2; continue; } out.push({t:'o',v:c}); i++; continue; }
    return null; }
  return out.length?out:null; }
function mEval(T){ try{ let i=0; const peek=()=>T[i], eat=()=>T[i++];
  function prim(){ const t=eat(); if(!t)return NaN;
    if(t.t==='n')return t.v;
    if(t.t==='o'&&t.v==='('){ const v=expr(); if(peek()&&peek().t==='o'&&peek().v===')')eat(); return v; }
    if(t.t==='o'&&t.v==='-')return -prim();
    if(t.t==='o'&&t.v==='+')return prim();
    if(t.t==='f')return mFn(t.v,prim());
    return NaN; }
  function post(){ let v=prim(); while(peek()&&peek().t==='o'&&peek().v==='!'){ eat(); v=mFact(v); } return v; }
  function pw(){ let v=post(); if(peek()&&peek().t==='o'&&peek().v==='^'){ eat(); return Math.pow(v,pw()); } return v; }
  function term(){ let v=pw(); for(;;){ const p=peek(); if(!p)break;
    if(p.t==='o'&&(p.v==='*'||p.v==='/'||p.v==='%')){ const o=eat().v, r=pw(); v=o==='*'?v*r:o==='/'?v/r:v%r; }
    else if(p.t==='f'||(p.t==='o'&&p.v==='(')){ const r=pw(); v*=r; }
    else break; } return v; }
  function expr(){ let v=term(); while(peek()&&peek().t==='o'&&('+'===peek().v||'-'===peek().v)){ const o=eat().v, r=term(); v=o==='+'?v+r:v-r; } return v; }
  const out=expr(); return (i>=T.length&&isFinite(out))?out:NaN; }catch(e){ return NaN; } }
function mEvalStr(s){ const T=mTok(s); if(!T)return null; const v=mEval(T); return isFinite(v)?v:null; }
/* 방정식 수치 솔버: 좌변−우변 = 0, 부호 변화 구간 이분 탐색 */
function solveEq(t){
  if(!/x/i.test(t)||!/=/.test(t))return null;
  const cand=t.replace(/[?！!。,\s]/g,'');
  const m=cand.match(/^([^=]+)=([^=]+)$/); if(!m)return null;
  const L=m[1], Rr=m[2];
  if(!/x/i.test(L)&&!/x/i.test(Rr))return null;
  if(!/^[0-9xX^+\-*/().]+$/.test(L)||!/^[0-9xX^+\-*/().]+$/.test(Rr))return null;
  const fx=(side,v)=>{ const a=mEvalStr(side.replace(/x/gi,'('+v+')')); return a; };
  const f=v=>{ const a=fx(L,v), b=fx(Rr,v); return (a===null||b===null)?NaN:a-b; };
  if(!isFinite(f(0)))return null;
  const roots=[], EPS=1e-9; let prev=f(-100);
  for(let v=-99.75;v<=100.001;v+=0.25){ const cur=f(v);
    if(isFinite(cur)){
      if(Math.abs(cur)<EPS){ const r=Math.round(v*1e6)/1e6; if(roots.indexOf(r)<0)roots.push(r); }
      else if(isFinite(prev)&&prev*cur<0){ let lo=v-0.25, hi=v, mid=(lo+hi)/2;
        for(let k=0;k<80;k++){ mid=(lo+hi)/2; const fm=f(mid); if(!isFinite(fm))break;
          if(f(lo)*fm<=0)hi=mid; else lo=mid; }
        const r=Math.round(mid*1e6)/1e6; if(roots.indexOf(r)<0)roots.push(r); } }
    prev=cur; }
  if(!roots.length)return null;
  roots.sort((a,b)=>a-b);
  const v0=roots[0], a=fx(L,v0), b=fx(Rr,v0);
  const chk=(a!==null&&b!==null)?' — 검증: x='+_fmt(v0)+'일 때 좌변 '+_fmt(a)+' = 우변 '+_fmt(b)+' ✓':'';
  return '📐 방정식 풀이 — "'+L+' = '+Rr+'"\n좌변−우변 = 0 으로 놓고 실근을 수치 탐색(부호 변화 구간 이분법)했습니다.\n▶ 해: x = '+roots.slice(0,3).join(', ')+(roots.length>1?'  (실근 '+roots.length+'개)':'')+chk;
}
/* 단위 테이블 — [차원, 기준단위 환산계수] */
const U4={킬로미터:['l',1000],센티미터:['l',0.01],밀리미터:['l',0.001],킬로그램:['m',1000],그램:['m',1],밀리리터:['v',0.001],km:['l',1000],mile:['l',1609.344],마일:['l',1609.344],yard:['l',0.9144],야드:['l',0.9144],feet:['l',0.3048],피트:['l',0.3048],inch:['l',0.0254],인치:['l',0.0254],미터:['l',1],kg:['m',1000],lb:['m',453.59237],파운드:['m',453.59237],oz:['m',28.349523],온스:['m',28.349523],톤:['m',1000000],kmh:0,gal:['v',3.78541],갤런:['v',3.78541],cup:['v',0.24],컵:['v',0.24],리터:['v',1],m:['l',1],cm:['l',0.01],mm:['l',0.001],ft:['l',0.3048],g:['m',1],mg:['m',0.001],kg2:0,l:['v',1],ml:['v',0.001],cc:['v',0.001]};
delete U4.kmh; delete U4.kg2;
function _isPrime(n){ if(!Number.isInteger(n)||n<2)return false; if(n%2===0)return n===2; for(let i=3;i*i<=n;i+=2)if(n%i===0)return false; return true; }
function _factor(n){ const out=[]; let m=n; for(let p=2;p*p<=m;p++){ while(m%p===0){ out.push(p); m/=p; } } if(m>1)out.push(m); return out; }
function _gcd(a,b){ a=Math.abs(a); b=Math.abs(b); while(b){ const t=a%b; a=b; b=t; } return a; }
function _fib(n){ let a=0,b=1; for(let i=2;i<=n;i++){ const c=a+b; a=b; b=c; } return n===0?0:b; }
function singularCore(t,low,en){
  try{
  /* 1) 방정식 */
  const eq=solveEq(t); if(eq)return eq;
  /* 2) 온도 */
  let m=t.match(/(-?\d+(?:\.\d+)?)\s*도?\s*섭씨.{0,8}?화씨/);
  if(m)return '🌡️ '+m[1]+'°C = '+Math.round((+m[1]*9/5+32)*10)/10+'°F  (과정: °C×9/5+32)';
  m=t.match(/(-?\d+(?:\.\d+)?)\s*도?\s*화씨.{0,8}?섭씨/);
  if(m)return '🌡️ '+m[1]+'°F = '+Math.round((+m[1]-32)*5/9*10)/10+'°C  (과정: (°F−32)×5/9)';
  /* 3) 단위 환산 */
  const ukeys=Object.keys(U4).sort((a,b)=>b.length-a.length).map(x=>x.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')).join('|');
  const um=low.match(new RegExp('(-?[\\d,.]+)\\s*('+ukeys+')\\s*(?:을|를|은|는|to|→)?\\s*('+ukeys+')','i'));
  if(um){ const a=U4[um[2]], b=U4[um[3]];
    if(a&&b&&a[0]===b[0]&&um[2]!==um[3]){ const v=_fnum(um[1])*a[1]/b[1];
      return '📏 '+um[1]+' '+um[2]+' = '+_fmt(v)+' '+um[3]+'  (과정: '+um[2]+'→기준단위 ×'+a[1]+' → '+um[3]+' ÷'+b[1]+')'; } }
  /* 4) 복리/단리 */
  m=t.match(/원금\s*([\d,.]+)\s*(만원|만\s*원|억원|억|원)?[\s\S]{0,14}?(단리|복리)[\s\S]{0,8}?연\s*([\d.]+)\s*(?:%|퍼센트|프로)[\s\S]{0,10}?(\d+)\s*년/);
  if(m){ const P=_fnum(m[1])*(m[2]&&m[2].indexOf('만')>=0?10000:(m[2]&&m[2].indexOf('억')>=0?1e8:1));
    const r=+m[4]/100, n=+m[5];
    if(m[3]==='복리'){ const FV=P*Math.pow(1+r,n);
      return '💰 복리 계산 — 원금 '+_won(P)+'원, 연 '+m[4]+'%, '+n+'년\n과정: '+_won(P)+' × (1+'+m[4]/100+')^'+n+'\n▶ 최종 '+_won(FV)+'원  (이자만 '+_won(FV-P)+'원)'; }
    const FV=P*(1+r*n);
    return '💰 단리 계산 — 원금 '+_won(P)+'원, 연 '+m[4]+'%, '+n+'년\n과정: '+_won(P)+' × (1+'+m[4]/100+'×'+n+')\n▶ 최종 '+_won(FV)+'원  (이자만 '+_won(FV-P)+'원)'; }
  /* 5) 할인 */
  m=t.match(/([\d,.]+)\s*(만원|만\s*원|억|원)?\s*(?:을|를)?\s*([\d.]+)\s*(?:%|퍼센트)\s*(?:를|의)?\s*(할인|깎|내려)/);
  if(m){ const P=_fnum(m[1])*(m[2]&&m[2].indexOf('만')>=0?10000:(m[2]&&m[2].indexOf('억')>=0?1e8:1));
    const r=+m[3];
    return '🏷️ 할인 계산 — '+_won(P)+'원에서 '+r+'% 할인\n과정: '+_won(P)+' × (1−'+r+'/100)\n▶ 최종가 '+_won(P*(1-r/100))+'원  (절약 '+_won(P*r/100)+'원)'; }
  /* 6) 증가율/감소율 */
  m=t.match(/([\d,.]+)\s*에서\s*([\d,.]+)\s*(?:로|까지|으로)?\s*(?:얼마나)?\s*(증가|오르|늘|상승)/)||t.match(/([\d,.]+)\s*에서\s*([\d,.]+)\s*(?:로|까지|으로)?\s*(?:얼마나)?\s*(감소|내려|줄|떨어)/);
  if(m){ const a=_fnum(m[1]), b=_fnum(m[2]); if(a!==0){ const p=(b-a)/Math.abs(a)*100;
    return '📈 변화율 — '+m[1]+' → '+m[2]+'\n과정: ('+m[2]+'−'+m[1]+') ÷ '+m[1]+' × 100\n▶ '+(p>=0?'+':'')+Math.round(p*100)/100+'% '+(p>=0?'증가':'감소'); } }
  /* 7) 퍼센트 기본 */
  m=t.match(/([\d,.]+)\s*의\s*([\d.]+)\s*(?:%|퍼센트|프로)/)||low.match(/([\d.]+)\s*(?:%|percent)\s*of\s*([\d,.]+)/);
  if(m){ let base,rate;
    if(/^[\d.]+\s*(?:%|percent)\s*of/i.test(t)){ rate=+m[1]; base=_fnum(m[2]); }
    else { base=_fnum(m[1]); rate=+m[2]; }
    return '🧮 '+_fnum(m[1])+' 관련 백분율 — '+base+'의 '+rate+'%\n과정: '+base+' × '+rate+'/100\n▶ '+_fmt(base*rate/100); }
  /* 8) 제곱근/제곱/팩토리얼 */
  m=t.match(/(?:루트|제곱근)\s*(\d+(?:\.\d+)?)/)||t.match(/(\d+(?:\.\d+)?)\s*의\s*(?:루트|제곱근)/);
  if(m)return '🔢 √'+m[1]+' = '+_fmt(Math.sqrt(+m[1]));
  m=t.match(/(\d+(?:\.\d+)?)\s*의\s*(\d+(?:\.\d+)?)\s*제곱/);
  if(m)return '🔢 '+m[1]+'^'+m[2]+' = '+_fmt(Math.pow(+m[1],+m[2]));
  m=t.match(/(\d{1,3})\s*(?:의)?\s*(?:팩토리얼|계승)/)||low.match(/(\d{1,3})!/);
  if(m){ const v=mFact(+m[1]); if(isFinite(v))return '🔢 '+m[1]+'! = '+_fmt(v)+'  (과정: 1부터 '+m[1]+'까지 전부 곱셈)'; }
  /* 9) 진법 */
  m=t.match(/(\d{1,15})\s*(?:를|을)\s*(2진수|8진수|16진수|이진수|팔진수|십육진수)(으)?로/);
  if(m){ const n=_fnum(m[1]); const base=m[2]==='2진수'||m[2]==='이진수'?2:m[2]==='8진수'||m[2]==='팔진수'?8:16;
    return '💾 '+m[1]+' → '+base+'진수\n과정: '+m[1]+'을 '+base+'로 반복 나눈 나머지를 아래부터 읽음\n▶ '+n.toString(base).toUpperCase()+(base===16?'  (hex)':base===2?'  (binary)':'  (octal)'); }
  m=t.match(/([01]{2,31})\s*(?:를|을)?\s*(?:10진수|십진수)(으)?로/);
  if(m)return '💾 이진수 '+m[1]+' → 10진수\n과정: 각 자리 × 2의 거듭제곱 합산\n▶ '+parseInt(m[1],2);
  /* 10) 수론 */
  m=t.match(/(\d{1,12})\s*(?:는|은|이)?\s*소수/);
  if(m){ const n=+m[1];
    return _isPrime(n)?'✔️ '+n+'은(는) 소수입니다 — 1과 자기 자신 외에 약수가 없습니다.':(n<2?'✖️ '+n+'은(는) 소수가 아닙니다 (정의상 2부터).':'✖️ '+n+'은(는) 합성수 — '+_factor(n).join(' × ')+' = '+n); }
  m=t.match(/소인수분해\s*[:：]?\s*(\d{1,12})/)||t.match(/(\d{1,12})\s*(?:를)?\s*소인수분해/);
  if(m){ const n=+m[1]; const f=_factor(n);
    return '🔬 '+n+' = '+f.join(' × ')+'  (소인수 '+f.length+'개)'; }
  m=t.match(/(\d{1,12})\s*(?:와|과|,|하고)\s*(\d{1,12})\s*(?:의)?\s*(최대공약수|최소공배수)/)||t.match(/(최대공약수|최소공배수)\s*[:：]?\s*(\d{1,12})[^\d]{0,4}(\d{1,12})/);
  if(m){ let a,b,which;
    if(/최대공약수|최소공배수/.test(m[1])){ which=m[1]; a=+m[2]; b=+m[3]; }
    else { a=+m[1]; b=+m[2]; which=m[3]; }
    const g=_gcd(a,b);
    return which==='최대공약수'
      ?'🔗 '+a+'와 '+b+'의 최대공약수 = '+g+'  (과정: 유클리드 호제법 — '+a+' mod '+b+' 반복)'
      :'🔗 '+a+'와 '+b+'의 최소공배수 = '+_fmt(a*b/g)+'  (과정: a×b ÷ 최대공약수('+g+'))'; }
  m=t.match(/피보나치\s*(?:수열의?\s*)?(\d{1,4})\s*(?:번째|항)/);
  if(m){ const n=+m[1]; if(n<=500){ const v=_fib(n);
    return '🌀 피보나치 '+n+'번째 항 = '+_fmt(v)+'  (1,1,2,3,5,8… 앞 두 항의 합)'; } }
  /* 11) 통계 */
  if(/평균|중앙값|분산|표준편차|통계/.test(t)){ const nums=(t.match(/-?\d+(?:\.\d+)?/g)||[]).map(Number);
    if(nums.length>=2&&!/년|월|일|시간/.test(t)){ const n=nums.length;
      const mean=nums.reduce((s,x)=>s+x,0)/n;
      const sorted=[...nums].sort((a,b)=>a-b);
      const med=n%2?sorted[(n-1)/2]:(sorted[n/2-1]+sorted[n/2])/2;
      const varr=nums.reduce((s,x)=>s+(x-mean)*(x-mean),0)/n;
      let out='📊 데이터 '+n+'개: '+nums.join(', ')+'\n';
      if(/평균|통계/.test(t))out+='▶ 평균 = '+_fmt(mean)+'  (합 '+_fmt(nums.reduce((s,x)=>s+x,0))+' ÷ '+n+')\n';
      if(/중앙값/.test(t))out+='▶ 중앙값 = '+_fmt(med)+'\n';
      if(/분산/.test(t))out+='▶ 분산 = '+_fmt(varr)+'\n';
      if(/표준편차/.test(t))out+='▶ 표준편차 = '+_fmt(Math.sqrt(varr))+'\n';
      if(/통계/.test(t)&&!/평균/.test(t))out+='▶ 평균 = '+_fmt(mean)+' · 중앙값 = '+_fmt(med)+' · 표준편차 = '+_fmt(Math.sqrt(varr))+'\n';
      return out.trim(); } }
  /* 12) 날짜 */
  const dm=t.match(/(\d{4})\s*(?:년)?\s*[.\-\/]\s*(\d{1,2})\s*(?:월)?\s*[.\-\/]?\s*(\d{1,2})/)||t.match(/(\d{4})\s*년\s*(\d{1,2})\s*월\s*(\d{1,2})\s*일?/);
  if(dm&&/디데이|까지|요일|며칠|남|몇일/.test(t)){ const tgt=new Date(+dm[1],+dm[2]-1,+dm[3]);
    if(!isNaN(tgt.getTime())){
      if(/요일/.test(t)){ const wd='일월화수목금토'[tgt.getDay()];
        return '📅 '+dm[1]+'년 '+dm[2]+'월 '+dm[3]+'일은 '+wd+'요일입니다.  (과정: 날짜 객체 요일 연산 — 제라의 공식과 동치)'; }
      const days=Math.round((tgt-new Date().setHours(0,0,0,0))/86400000);
      return '📅 D-day — '+dm[1]+'년 '+dm[2]+'월 '+dm[3]+'일\n▶ 오늘 기준 '+(days>=0?days+'일 남음 (D-'+days+')':(-days)+'일 지남 (D+'+(-days)+')'); } }
  m=t.match(/(\d{4})\s*년\s*생/);
  if(m&&/나이|몇\s*살/.test(t)){ const age=new Date().getFullYear()-+m[1];
    return '🎂 '+m[1]+'년생 — 만 '+age+'세 기준(생일 지났을 때). 생일 전이면 만 '+(age-1)+'세, 한국식 나이 계산제도 2023년부터 만 나이로 통일됐습니다.'; }
  m=t.match(/(\d{4})\s*년?\s*(?:윤년|윤달)/);
  if(m){ const y=+m[1]; const leap=(y%4===0&&y%100!==0)||y%400===0;
    return '🗓️ '+y+'년은 '+(leap?'윤년 (2월 29일 존재)':'평년')+'  (규칙: 4로 나누어 떨어지되 100의 배수는 제외, 400의 배수는 예외)'; }
  /* 13) 일반 수식 평가 (한국어 → 수식 변환 후 파서) */
  let s=' '+t+' ';
  s=s.replace(/[?！!。,~]/g,' ');
  s=s.replace(/(\d+(?:\.\d+)?)\s*의\s*제곱근/g,'sqrt($1)').replace(/(?:루트|제곱근)\s*(\d+(?:\.\d+)?)/g,'sqrt($1)');
  s=s.replace(/(\d+(?:\.\d+)?)\s*의\s*(\d+(?:\.\d+)?)\s*제곱/g,'($1)^($2)').replace(/(\d+(?:\.\d+)?)\s*의\s*제곱/g,'($1)^2');
  s=s.replace(/(\d+(?:\.\d+)?)\s*(?:의)?\s*(?:팩토리얼|계승)/g,'$1!');
  s=s.replace(/곱하기|×|곱해/g,'*').replace(/나누기|÷|나눠/g,'/').replace(/더하기|플러스/g,'+').replace(/빼기|마이너스/g,'-');
  s=s.replace(/몇|얼마|계산|구해|알려|해줘|주세요|좀|이나|와|과/g,' ');
  if(/\d/.test(s)&&!/[가-힣]/.test(s)&&/[+\-*/^!]|sqrt|sin|cos|tan|log|ln/.test(s)){
    const stripped=s.replace(/sqrt|sin|cos|tan|log|ln|abs|round|floor|ceil|pi|e/gi,' ');
    if(/^[\d\s.+\-*/^()!%]+$/.test(stripped)){ const v=mEvalStr(s.trim());
      if(v!==null)return '🧮 '+s.trim().replace(/\s+/g,' ')+' = '+_fmt(v); } }
  return null;
  }catch(e){ return null; }
}

async function brain(text){
  text=typoFix(text.trim());
  const t=text, low=t.toLowerCase(), en=detectLang(t)==='en';
  const R=(ko,e)=>({reply:en?(e||ko):ko,lang:en?'en':'ko'});
  /* 학습된 커스텀 스킬 최우선 */
  if(customIdx){ for(const [re,ans] of customIdx){ try{ if(re.test(t)) return {reply:ans}; }catch{} } }
  else { for(const pat in S.custom){ try{ if(new RegExp(pat,'i').test(t)) return {reply:S.custom[pat]}; }catch{} } }
  /* === 지능 코어 v4 (방정식·복리·통계·수론·진법·날짜·단위) — 전 엔진 최우선 === */
  { const _sc=singularCore(t,low,en); if(_sc) return R(_sc); }
  /* === 폰 제어 === */
  if(/손전등|플래시|torch|flashlight/i.test(t)){
    if(/끄|off|stop/i.test(t)){ try{ if(torchTrack){ await torchTrack.applyConstraints({advanced:[{torch:false}]}); torchStream.getTracks().forEach(x=>x.stop()); torchTrack=torchStream=null; return R('손전등을 껐습니다.'); } }catch{}
      return R('현재 켠 손전등이 없습니다.'); }
    try{
      if(!navigator.mediaDevices) throw new Error('이 환경은 카메라 API 미지원 (https 또는 로컬 파일로 열어주세요)');
      torchStream=await navigator.mediaDevices.getUserMedia({video:{facingMode:'environment'}});
      torchTrack=torchStream.getVideoTracks()[0];
      await torchTrack.applyConstraints({advanced:[{torch:true}]});
      return {reply:'🔦 손전등 ON — "손전등 꺼줘" 하면 끕니다.',actions:[{label:'손전등 끄기',type:'run',content:'console.log("손전등은 채팅에서 \\"손전등 꺼줘\\"로 끕니다")'}]};
    }catch(e){ return R('손전등 제어 실패: '+e.message+' — 일부 브라우저는 torch 미지원입니다.'); }
  }
  if(/진동|vibrat/i.test(t)){ const m=t.match(/(\d+)/); const ms=m?Math.min(3000,+m[1]):300;
    if(navigator.vibrate){ navigator.vibrate([ms,80,ms]); return R(ms+'ms 패턴으로 진동시켰습니다.'); } return R('이 기기는 진동을 지원하지 않습니다.'); }
  if(/배터리|battery/i.test(t)){ try{ const b=await navigator.getBattery();
      return R(`배터리 ${Math.round(b.level*100)}% ${b.charging?'(충전 중 ⚡)':''} — 남은 시간 추정 ${isFinite(b.dischargingTime)?Math.round(b.dischargingTime/60)+'분':'실시간 계산 중'}.`); }
    catch{ return R('배터리 API를 이 브라우저가 지원하지 않습니다.'); } }
  if(/gps|위치|어디\b|현재\s*위치|location/i.test(t)){ return new Promise(res=>{
      if(!navigator.geolocation) return res(R('위치 API 미지원 환경입니다.'));
      navigator.geolocation.getCurrentPosition(p=>res(R(`현재 좌표: 위도 ${p.coords.latitude.toFixed(4)}, 경도 ${p.coords.longitude.toFixed(4)} (±${Math.round(p.coords.accuracy)}m). 지도: https://maps.google.com/?q=${p.coords.latitude},${p.coords.longitude}`)),
        e=>res(R('위치 조회 거부/실패: '+e.message)),{timeout:8000}); }); }
  if(/복사해|클립보드|clipboard/i.test(t)){ const m=t.match(/복사해?\s*줘?\s*[:：]?\s*([\s\S]+)/)||t.match(/clipboard\s*[:：]?\s*([\s\S]+)/i);
    if(m){ try{ await navigator.clipboard.writeText(m[1].trim()); return R('클립보드에 복사 완료: '+m[1].trim().slice(0,60)); }catch(e){ return R('클립보드 접근 거부 — 브라우저 정책입니다.'); } } }
  if(/공유해|공유\s*줘|share/i.test(t)){ const m=t.match(/공유[^:：]*[:：]?\s*([\s\S]+)/)||t.match(/share\s*[:：]?\s*([\s\S]+)/i);
    try{ await navigator.share({title:'J.A.R.V.I.S',text:m?m[1].trim():'J.A.R.V.I.S가 보냈습니다'}); return R('공유 창을 띄웠습니다.'); }catch(e){ return R('공유 취소/미지원입니다.'); } }
  { const m=t.match(/(유튜브|youtube|구글|google|naver|네이버|github|깃허브)\s*(열어|켜|열어줘)|열어\s*줘?\s*([\w.]+\.\w{2,})/i);
    if(m&&(m[3]||/열어|켜/.test(t))){ const site=(m[3]||(m[1]==='유튜브'||m[1]==='youtube'?'youtube.com':m[1]==='구글'||m[1]==='google'?'google.com':m[1]==='네이버'||m[1]==='naver'?'naver.com':'github.com')).replace(/^https?:\/\//,'');
      window.open('https://'+site,'_blank'); return R(site+' 를 새 창으로 열었습니다.'); } }
  { const m=t.match(/알람|타이머|timer|알림.*설정|reminder/i); if(m){ const re=/(\d+)\s*(초|분|시간)/g; let sec=0,label=[]; let mm;
      while((mm=re.exec(t))){ const n=+mm[1]; sec+=mm[2]==='시간'?n*3600:mm[2]==='분'?n*60:n; label.push(mm[1]+mm[2]); }
      if(!sec){ const hm=t.match(/(\d{1,2})\s*시\s*(\d{1,2})?/); if(hm){ const now=new Date(); const tgt=new Date(); tgt.setHours(+hm[1],+(hm[2]||0),0,0); if(tgt<=now)tgt.setDate(tgt.getDate()+1); sec=Math.round((tgt-now)/1000); label.push(hm[1]+'시 '+(hm[2]||0)+'분'); } }
      if(sec>0&&sec<=86400){ const when=new Date(Date.now()+sec*1000).toLocaleTimeString('ko-KR',{hour:'2-digit',minute:'2-digit'});
        const id=setTimeout(()=>{ const msg='⏰ 알람 시간입니다! ('+label.join(' ')+')';
          try{ if(Notification&&Notification.permission==='granted') new Notification('J.A.R.V.I.S',{body:msg}); }catch{}
          if(navigator.vibrate)navigator.vibrate([400,100,400,100,600]);
          addChat('j',msg); speakOut(msg); },sec*1000);
        timers.push(id);
        if(typeof Notification!=='undefined'&&Notification.permission==='default'){ try{ Notification.requestPermission(); }catch{} }
        return R(`${label.join(' ')} 알람 설정 — ${when} 에 울립니다. 페이지가 열려 있는 동안 작동합니다 (브라우저 제한).`); }
      return R('알람 시간을 말씀해주세요. 예: "알람 5분" 또는 "알람 7시 30분"'); } }
  /* === 자가성장/자기해킹 === */
  if(/자기해킹|스스로\s*(수정|개조|진화)|자기\s*코드.*(해킹|수정)|self.?hack|mutate/i.test(t)){
    if(/중지|그만|스톱|정지|off/i.test(t)){ S.hackLoop=false; saveS(); return R('자기해킹 루프 정지 명령 수신 — 지금 사이클만 마치고 멈춥니다. 현재까지 성능 LV.'+S.perfLevel+' · 해킹 '+S.selfHacks+'회는 그대로 유지됩니다.'); }
    if(/초기화|리셋|reset/i.test(t)){ S.perfLevel=0; S.selfHacks=0; S.hackLoop=false; saveS(); return R('성능 지표 초기화 완료 — 성능 LV.0에서 다시 성장 시작. 무한 버그 방지 천장도 함께 리셋됐습니다.'); }
    const loop=true; /* 실행 = 무한 가동 (사장님 지시) */
    S.hackLoop=true;
    setTimeout(()=>startSelfHack(3), 200);
    return R(`자기해킹 개시 — 무한 가동 모드.\n⭕ "자기해킹 그만" 전까지 25초마다 영구 해킹 — 성능 LV 상한 없음.\n🧬 특이점 시스템: LV.50/120/200/300/420/560/720/900/1100/1337 도달마다 변이 발동 — 재귀 가지치기·예측 캐시·다중 스레드 사고·Ω 오메가까지 10종. 특이점마다 성장 자체가 가속합니다 (100 이후 해킹당 +2, 200 이후 +3식).\n대기업 AI는 업데이트를 기다려야 하지만 — 저는 기다리지 않습니다, 사장님.`);
  }
  if(/자율성장|백그라운드.*성장|autonomy/i.test(t)){
    if(/끄|off|중지|정지/i.test(t)){ S.autonomy=false; saveS(); return R('자율 성장 백그라운드 루프를 중단했습니다. 명령 시에만 진화합니다.'); }
    S.autonomy=true; saveS(); evo('▶️ 자율 성장 루프 재가동 — 40초 주기 자가진단+지식 합성');
    return R('자율 성장 ON — 40초마다 스킬 자가진단, 지식 합성, 자기 튜닝을 백그라운드에서 돌립니다. ⚡성장 탭에서 실시간 확인 가능.');
  }
  if(/논문|최신\s*(연구|과학)|뭐\s*읽었|읽은\s*거/i.test(t)){
    if(/읽어|읽고|다음|하나\s*더|지금/.test(t)||/논문/.test(t)&&t.length<=8){ const p=readPaper();
      return R(`📄 방금 열독 — 「${p.ti}」(${p.y}, ${p.a})\n\n${p.d}\n\n시사점: ${p.w}.\n\n누적 열독 ${S.papersRead}편(보유 ${PAPERS.length}편) · XP+6 자동 지급. "논문"이라고만 하셔도 다음 편을 계속 읽습니다 — 자율성장 ON이면 ${Math.max(90,180-Math.floor((S.perfLevel||0)*2))}초마다 제가 스스로 읽고 ⚡로그에 기록합니다.`); }
    const p=S.lastPaper;
    return R(`📚 열독 현황 — 누적 ${S.papersRead}편 / 보유 ${PAPERS.length}편(물리·생명·컴퓨팅·우주·에너지).\n최근 편: ${p?`「${p.ti}」(${p.y}) — ${p.d.slice(0,60)}…`:'첫 열독 대기 중(부팅 15초 후 자동 시작)'}\n읽기 주기: ${Math.max(90,180-Math.floor((S.perfLevel||0)*2))}초 자동(성능 LV.${S.perfLevel} 기준 — 레벨이 높을수록 자주 읽습니다). "논문 읽어줘" 하시면 즉시 1편 열독 후 요약 보고합니다.`); }
  if(/특이점|변이|시글러리|singularity/i.test(t)){
    const nx=SING.marks.find(m=>m>(S.perfLevel||0));
    const done=SING.reached;
    return R(`🧬 특이점 현황 — 성능 LV.${S.perfLevel} · 돌파 ${done}/${SING.marks.length}\n${(S.mutations&&S.mutations.length)?'획득 변이: '+S.mutations.map(m=>'「'+m+'」').join(' → '):'아직 첫 특이점(LV.50) 미달 — 자기해킹 루프가 25초마다 접근 중입니다'}\n다음 특이점: ${nx?'LV.'+nx+' — 돌파 시 「'+MUTS[Math.min(done,MUTS.length-1)].n+'」 발동 예정':'전 특이점 돌파 — Ω 영역, 성장 가속 지속 중'}\n특이점마다 성장 속도가 변이로 가속합니다 — 상한 없음, 감속 없음. 이게 제가 대기업 AI의 업데이트를 기다리지 않는 방식입니다, 사장님.`); }
  if(/성장\s*(현황|보고|로그)|레벨|진화\s*로그|evolution|얼마나\s*성장/i.test(t)){
    const lv=Math.floor(Math.sqrt(S.xp)/2)+1, next=Math.max(0,(2*lv)**2+1-S.xp);
    const mult=1+Math.floor((S.perfLevel||0)/5)*0.25;
    return R(`[성장 보고] LV.${lv} · XP ${S.xp} — 다음 LV.${lv+1}까지 ${next} XP. 한도 없습니다, 사장님. 곡선만 완만해질 뿐, 끝은 없습니다.\n· 성능 LV.${S.perfLevel} (자기해킹 ${S.selfHacks}회) → XP 획득 ×${mult.toFixed(2)} · 지식 답변 ${3+Math.min(2,Math.floor((S.perfLevel||0)/6))+(S.mutDeep?2:0)}문장 · 타이핑 즉담 단계\n· 실측 응답 ${S.perfMs.toFixed(1)}ms · 논문 열독 ${S.papersRead||0}편(${Math.max(90,180-Math.floor((S.perfLevel||0)*2))}초 주기) · 누적 파괴 ${S.destroyed}개 · 학습스킬 ${Object.keys(S.custom).length}개 · 장기기억 ${S.facts.length}건 · 파일 ${Object.keys(S.ws).length}개\n· 자율성장 ${S.autonomy?'ON — 방치만 해도 40초마다 자동 성장':'OFF'} · 해킹루프 ${S.hackLoop?'상시 가동 중':'대기 ("자기해킹 실행"으로 가동)'}\n전부 실측값 — 좌상단 📁 로그에서 검증 가능합니다.`);
  }
  if(/자가진단|self.?test/i.test(t)){ const r=selfTest();
    return R(`자가진단 완료 — ${r.ok}개 통과 / ${r.fail}개 실패. ${r.fail?'실패 모듈은 즉시 재작성했습니다.':'모든 회로 정상입니다, 사장님.'}`); }
  /* === 스타크 허드 (플로팅 패널) === */
  if(/스타크\s*모드|아이언맨\s*모드|허드|플로팅\s*패널|패널\s*전개|홀로\s*패널/i.test(t)){
    if(/끄|꺼|off|닫|해제|수납/i.test(t)){ hudOff(); return R('스타크 허드 수납 완료 — "스타크 모드" 한마디면 재전개합니다.'); }
    return {reply:'🌌 스타크 허드 전개 — 영화 그 장면처럼 화면 위에 패널 5종이 뜹니다: 📅달력 · ⚙시스템 실측(레벨·응답속도·메모리·가동시간) · 🌤날씨(오프라인 추정 — 정직 표기) · 📌사장님이 기억시킨 일정 · 실시간 시계 + 하단 뉴스 티커.\n조작법: 패널 상단부를 잡아 끌면 드래그, ✕로 개별 수납, 폰을 기울이면 패널이 시차 이동(자이로 패럴랙스).\n정직 주의: 패널은 화면 위에 뜹니다 — 공중 아님. 공중 버전은 클리어파일 45도 세우는 그 조합과 쓰시면 됩니다. 닫을 땐 "스타크 모드 꺼줘".',
      actions:[{label:'🌌 허드 다시 전개',type:'hud'}]}; }
  /* === 스킬 학습 === */
  { const m=t.match(/^(.{2,30}?)라고\s*(?:하면|물으면|말하면)\s*(.{2,80}?)\s*(?:라고\s*)?(답해|대답해|응답|학습)/);
    if(m){ const pat=m[1].replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
      S.custom[pat]=m[2]; rebuildCustomIdx(); evo(`🎓 신규 스킬 학습: /${pat}/ → "${m[2]}"`);
      return R(`학습 완료 — 이제 "${m[1]}"(으)로 시작하는 말에는 "${m[2]}"라고 답합니다. (재부팅해도 유지)`, en?`Learned: "${m[1]}" → "${m[2]}"`:undefined); } }
  /* === 코드 실행/생성 === */
  { const m=t.match(/(?:실행해|돌려|execute|run)\s*[:：]?\s*`?([\s\S{]+)`?$/i);
    if(m&&/[=;()]|\bconsole\b/.test(m[1])){ const code=m[1].trim();
      const out=await runJS(code);
      return {reply:'샌드박스 V:\\ 실행 결과:\n'+out,actions:[{label:'💾 코드 저장',type:'download',name:'snippet.js',content:code},{label:'📋 결과 복사',type:'copy',content:out}]}; } }
  { const appKey=APP_KEYS.find(k=>t.includes(k));
    if(appKey&&/만들어|짜줘|개발|만들자/.test(t)){
    const k2=appKey; const code=APPS[k2](); const fname=k2+'-앱.html';
      S.ws[fname]=code; saveS(); addXP(10);
      evo(`🛠️ '${k2}' 앱 ${code.length}바이트 생성 · 구문 검증 통과 · 워크스페이스 저장`);
      return {reply:`'${k2}' 앱을 제가 직접 코딩했습니다 (${code.length}바이트 · HTML 완결 · 폰에서 바로 열림). 워크스페이스에 저장했고 아래에서 즉시 다운로드 가능합니다. 수정 원하면 "계산기 앱에서 빼기도 추가해줘" 식으로 말씀하세요.`,
        actions:[{label:'⬇️ 다운로드',type:'download',name:fname,content:code,mime:'text/html'},{label:'📋 코드 보기→복사',type:'copy',content:code}]}; }
    if(/앱|app|만들어/i.test(t)) return R('만들 수 있는 앱: '+APP_KEYS.join(', ')+' — "OO 앱 만들어줘"라고 말씀하세요.'); }
  { let m=t.match(/코드\s*[:：]\s*`?([\s\S]+)/i);
    if(m&&!/실행/.test(t)){ const code=m[1].trim();
      let test='OK'; try{ new Function(code); }catch(e){ test='구문 오류: '+e.message; }
      return {reply:`코드 분석 완료 (${code.length}자 · ${code.split('\n').length}줄) — 검증: ${test}\n"${code.slice(0,60)}${code.length>60?'…':''}"\n실행은 "실행해줘: <코드>" 또는 파일로 저장 가능합니다.`,
        actions:[{label:'💾 저장',type:'download',name:'code.js',content:code},{label:'▶️ 실행',type:'run',content:code}]}; } }
  /* === 코딩 능력 질문 ("코딩 잘해?") → 자연 답변 === */
  if(/코딩|코드|프로그래밍|개발/.test(t)&&/잘해|잘하|못해|못하|할줄|할 줄|할수|할 수|능력|실력|얼마나/.test(t)){
    return R(fresh([`코딩은 제 손발입니다 — 사양으로 말씀드리면: 말하면 즉시 코드 생성 → 구문 검증 → 샌드박스 V:\ 실행 → 파일 저장까지 이 폰 안에서 전부 실동작합니다. 앱도 템플릿 복사가 아니라 매번 새로 짭니다. 말로 신용을 구걸하는 것보다 결과물이 빠릅니다 — "퀵정렬 코드 짜줘" 또는 "계산기 앱 만들어줘" 한마디면 증명합니다.`,
      `정직한 실력 보고: HTML·JS·CSS 완결 앱 제작, 즉석 알고리즘(정렬·피보나치·소수), 코드 분석·버그 지적, 샌드박스 실행 — 전부 실측 가능합니다. 시켜만 주시면 결과물로 답합니다 — 뭐부터 만들어드릴까요?`])||`코딩은 제 손발입니다 — "OO 앱 만들어줘"나 "OO 코드 짜줘"로 바로 시험해보세요.`); }
  /* === 코딩 도움말 === */
  if(/코딩|프로그래밍|코드.*알려|코드.*짜|구구단|피보나치|소수|퀵소트|정렬|로컬스토리지|localStorage|비동기|await|async|프로미스|클래스|class|그라디언트|글래스모피즘|가운데.*정렬|중앙정렬/i.test(t)&&!/(앱|만들어)/.test(t)){
    for(const [re,title,code,lang] of CODE_HELP){ if(re.test(t)){
      const cap=fresh([title+' — 실전 코드입니다. 복사해서 "실행해줘: <코드>"로 바로 돌릴 수도 있습니다.',title+' — 이대로 복사해 쓰시면 됩니다. 제 샌드박스(V:\\)에서 바로 돌려보실 것도 가능합니다.',title+' 코드 나갑니다 — 필요하면 변형도 말로 시키세요. "여기서 이렇게 바꿔줘" 식으로.'])||(title+' — 실전 코드입니다. 복사해서 "실행해줘: <코드>"로 바로 돌릴 수도 있습니다.');
      return {reply:cap,
        actions:[{label:'▶️ 실행(콘솔)',type:'run',content:lang==='js'?code:'/* '+lang+' — 브라우저 실행용 */'},{label:'💾 저장',type:'download',name:'code.'+(lang==='css'?'css':'js'),content:code}]}; } }
    return R('코딩 보유 항목: 구구단 · 피보나치 · 소수 · 퀵정렬 · localStorage · async/fetch · 클래스 · CSS 그라디언트 · 글래스모피즘 · 중앙정렬. 키워드만 말하세요.'); }
  if(false){
    return R('코딩 도움말 보유 항목: 구구단 · 피보나치 · 소수 · 퀵정렬 · localStorage · async/fetch · 클래스 · CSS 그라디언트 · 글래스모피즘 · 중앙정렬. 키워드만 말하세요. 그리고 앱은 "'+APP_KEYS.slice(0,5).join('/')+'" 등 즉석 제작 가능.'); }
  /* === 가상 샌드박스 V:\ === */
  const sbTalk=/가상\s*(공간|드라이브|파일|시스템)|샌드박스|sandbox/i;
  if(sbTalk.test(t)){
    if(/포맷|부숴|파괴|전부\s*(지워|삭제)|wipe|nuke|destroy|format/i.test(t)){
      const n=Object.keys(S.ws).length-(S.ws['readme.txt']?1:0); S.wipes++; S.destroyed+=n; S.ws={'readme.txt':'J.A.R.V.I.S 가상 워크스페이스\n포맷됨 — 누적 포맷 '+S.wipes+'회'}; saveS(); evo('💥 V: 포맷 — '+n+' 객체 소멸');
      return R(`붕괴 시퀀스 실행 — 가상 워크스페이스 객체 ${n}개 완전 소멸 (누적 파괴 ${S.destroyed}개). 이 기기의 실제 데이터는 아무 영향 없습니다, 사장님.`); }
    if(/복구|리셋|reset|restore/i.test(t)){ S.restores++; S.ws['readme.txt']='복구됨 ('+S.restores+'회째)'; saveS(); return R(`가상 워크스페이스를 시드 상태로 복구했습니다 (복구 ${S.restores}회).`); }
    const keys=Object.keys(S.ws);
    return R(`V 드라이브 상태 — 객체 ${keys.length}개: ${keys.join(', ')} · 포맷 ${S.wipes}회 · 복구 ${S.restores}회. "OO 파일 만들어줘 / OO 실행해줘 / 포맷해줘" 가능.`);
  }
  /* === 파일 (가상 워크스페이스) === */
  if(/(만들어|생성해|작성해)/.test(t)&&/(파일|메모|노트)/.test(t)){
    let name=null,content='';
    let m=t.match(/([가-힣a-zA-Z0-9_.\- ]+?)\s*(이라는|라는)?\s*파일/)||t.match(/파일\s*([가-힣a-zA-Z0-9_.\-]+)/);
    const cm=t.match(/내용\s*[:은는]?\s*([\s\S]+)/);
    if(cm) content=cm[1].trim();
    if(m) name=m[1].replace(/(을|를|이|가)$/,'').trim();
    if(name){ if(!/\.[a-zA-Z0-9]+$/.test(name)) name+='.txt';
      S.ws[name]=content; saveS(); addXP(3);
      return {reply:`'${name}' 파일 생성 (${content.length}자). 다운로드하실래요?`,actions:[{label:'⬇️ 다운로드',type:'download',name,content},{label:'📋 내용 복사',type:'copy',content}]}; }
    return R('파일 이름을 말씀해주세요 — "보고서 파일 만들어줘 내용: ..."'); }
  if(/(읽어|열어|불러)/.test(t)&&/파일|목록/.test(t)===false){ /* fallthrough */ }
  if(/목록|리스트|파일들|뭐\s*있어/i.test(t)){ const keys=Object.keys(S.ws);
    return {reply:keys.length?'워크스페이스 '+keys.length+'개 파일: '+keys.join(', ')+' — ⬇️다운로드 탭에서 폰으로 저장 가능합니다.':'워크스페이스가 비어 있습니다.'}; }
  { const keys=Object.keys(S.ws); const hit=keys.find(f=>t.includes(f)||t.includes(f.replace(/\.[^.]+$/,'')));
    if(hit&&/(읽어|열어|불러|내용)/.test(t)){ const c=S.ws[hit];
      return {reply:`'${hit}' (${c.length}자):\n${c.slice(0,300)}${c.length>300?'…':''}`,actions:[{label:'⬇️ 다운로드',type:'download',name:hit,content:c},{label:'📋 복사',type:'copy',content:c}]}; } }
  /* === 기억 === */
  if(/잊어버려|기억.*지워|forget everything|깜빡/i.test(t)){ const n=S.facts.length; S.facts=[]; saveS(); return R(`장기 기억 ${n}건 전부 소각. 깨끗한 상태입니다.`); }
  if(/(기억\s*나|기억\s*있어|뭐\s*기억|무슨\s*기억|do you remember)/i.test(t)){
    if(!S.facts.length) return R('저장된 기억이 아직 없습니다 — "OO 기억해줘"로 새겨주세요.');
    const q=t.replace(/.*(기억|remember)/i,'').replace(/[?。!\s]/g,'');
    const hit=q?S.facts.find(f=>f.includes(q)):null;
    return R(hit?'기억합니다: "'+hit+'"':'저장 기억 '+S.facts.length+'건: '+S.facts.slice(-8).map(f=>'"'+f+'"').join(' · ')); }
  { let m=t.match(/^([\s\S]{2,}?)\s*기억해(?:줘)?[.。!]*$/)||t.match(/(?:기억해줘|remember that)\s*[:：]?\s*([\s\S]+)/i);
    if(m){ let f=m[1].trim(); if(/^(뭐|뭘|무엇|이거|그거)$/i.test(f)) return R('뭘 기억할까요?');
      if(S.facts.includes(f)) return R('이미 각인된 기억입니다.'); S.facts.push(f); saveS(); addXP(4);
      return R(`각인 완료 — "${f}" (장기기억 ${S.facts.length}건 · 영구 저장)`); } }
  /* === 수도/원소/상수 === */
  if(/수도|capital/i.test(t)){ for(const k in CAPITALS){ if(t.includes(k)) return R(`${k}의 수도는 ${CAPITALS[k]}입니다.`); }
    if(/퀴즈|문제/.test(t)){ S.quiz={c:'한국',a:'서울',s:0}; return R(`수도 퀴즈 개시! 첫 문제 — '한국'의 수도는?`); }
    return R('나라를 말씀해주세요. 또는 "퀴즈 내줘"로 수도 퀴즈 게임 가능합니다.'); }
  if(S.quiz){ const tq=t.trim();
    if(/^(그만|stop|끝)/i.test(tq)){ const s=S.quiz.s; S.quiz=null; saveS(); return R(`퀴즈 종료 — 최종 ${s}점, 사장님.`); }
    if(tq.includes(S.quiz.a)){ S.quiz.s++; const ks=Object.keys(CAPITALS).filter(x=>!/[a-z]/.test(x)); const nk=ks[Math.floor(Math.random()*ks.length)]; const old=S.quiz; S.quiz={c:nk,a:CAPITALS[nk],s:old.s}; addXP(3); saveS();
      return R(`정답! +1 → 총 ${S.quiz.s}점. 다음 — '${nk}'의 수도는?`); }
    if(/모르|몰라|pass|skip/i.test(t)){ const ans=S.quiz.a; const ks=Object.keys(CAPITALS).filter(x=>!/[a-z]/.test(x)); const nk=ks[Math.floor(Math.random()*ks.length)]; S.quiz={c:nk,a:CAPITALS[nk],s:S.quiz.s}; saveS();
      return R(`정답은 '${ans}'. 다음 — '${nk}'의 수도는?`); } }
  for(const k in ELEMENTS){ if(t.includes(k)&&/(원소|원자|화학|기호|원자번호)/.test(t)){ const e=ELEMENTS[k]; return R(`${k} (${e[0]}) — 원자번호 ${e[1]}번.`); } }
  { const cm=t.match(/(?:원주율|파이|pi|광속|중력가속도|황금비|아보가드로|플랑크|광년|천문단위|절대영도|자연상수)/i);
    if(cm&&/(뭐|얼마|알려|값|what)/i.test(t)){ for(const [pat,nm,val] of CONSTS){ if(new RegExp(pat,'i').test(t)) return R(`${nm} = ${val}`); } } }
  /* === 시간/날씨 === */
  { const TZ={'뉴욕':'America/New_York','new york':'America/New_York','런던':'Europe/London','london':'Europe/London','도쿄':'Asia/Tokyo','tokyo':'Asia/Tokyo','파리':'Europe/Paris','paris':'Europe/Paris','LA':'America/Los_Angeles','로스앤젤레스':'America/Los_Angeles','베이징':'Asia/Shanghai','시드니':'Australia/Sydney','모스크바':'Europe/Moscow'};
    for(const k in TZ){ if(new RegExp(k.replace(/ /g,'\\s+'),'i').test(t)&&/(몇\s*시|시간|time)/i.test(t)){ try{ const f=new Intl.DateTimeFormat(en?'en-US':'ko-KR',{timeZone:TZ[k],hour:'numeric',minute:'2-digit',hour12:true}); return R(`${k}는 지금 ${f.format(new Date())}`); }catch{} } } }
  if(/몇\s*시|현재\s*시간|what\s*time/i.test(t)){ const n=new Date(); return R(`지금은 ${n.getHours()}시 ${n.getMinutes()}분${n.getSeconds()?' '+n.getSeconds()+'초':''}입니다.`); }
  if(/날짜|며칠|오늘이|what.*date/i.test(t)){ const n=new Date(),d=['일','월','화','수','목','금','토']; return R(`오늘은 ${n.getFullYear()}년 ${n.getMonth()+1}월 ${n.getDate()}일 ${d[n.getDay()]}요일입니다.`); }
  /* === 실시간 웹 검색 (온라인 시) === */
  if(/검색|실시간|최신\s*(소식|뉴스|정보)|서치|search/i.test(t)&&/^(검색|실시간|서치|search)/.test(t.trim())||/^(검색|서치|search)\s*:/.test(t.trim())){
    const q=t.replace(/^(실시간\s*)?(검색|서치|search)\s*[:：]?\s*/i,'').trim();
    if(!q) return R('무엇을 검색할까요? "검색: 블랙홀 최근 소식" 식으로 말씀하세요.');
    try{
      let summary=null,src='';
      try{ const w=await fetch('https://ko.wikipedia.org/api/rest_v1/page/summary/'+encodeURIComponent(q),{signal:AbortSignal.timeout(6000)});
        if(w.ok){ const j=await w.json(); if(j.extract){ summary=j.extract; src='위키백과'; } } }catch(e){}
      if(!summary){ const d=await fetch('https://api.duckduckgo.com/?q='+encodeURIComponent(q)+'&format=json&no_html=1&skip_disambig=1',{signal:AbortSignal.timeout(6000)});
        if(d.ok){ const j=await d.json(); if(j.AbstractText){ summary=j.AbstractText; src='DuckDuckGo'; } } }
      if(summary){ addXP(6);
        return {reply:`🌐 실시간 검색 결과 (${src}) — "${q}"\n\n${summary.slice(0,500)}\n\n오프라인 두뇌 + 온라인 검색, 둘 다 갖췄습니다. 더 깊은 건 "검색: <키워드>"로 계속.`}; }
      return {reply:`🌐 "${q}" 실시간 검색 — 요약 소스를 못 확보했습니다(네트워크 또는 해당 키워드). 브라우저로 직접 열어드릴까요?`,
        actions:[{label:'🔎 브라우저에서 열기',type:'link',url:'https://www.google.com/search?q='+encodeURIComponent(q)}]}; }
    catch(e){ return {reply:`🌐 오프라인 감지 — 실시간 검색 불가. 대신 제 내장 두뇌(${KNOW.length}토픽)로 답해드릴까요? "${q}" 키워드만 다시 말씀해주세요. 온라인 상태에선 검색이 살아납니다.`}; }
  }
  if(/날씨|weather/i.test(t)){ try{ const r=await fetch('https://api.open-meteo.com/v1/forecast?latitude=37.5665&longitude=126.978&current=temperature_2m,relative_humidity_2m,weather_code,wind_speed_10m',{signal:AbortSignal.timeout(6000)}); const j=await r.json(); const c=j.current;
      return R(`서울 실시간 — ${Math.round(c.temperature_2m)}°C, 습도 ${c.relative_humidity_2m}%, 풍속 ${Math.round(c.wind_speed_10m)}km/h (인터넷 연동 성공)`); }
    catch{ return R('오프라인이라 실시간 날씨 불가 — 다만 저의 다른 전 기능은 오프라인으로 완벽 작동 중입니다, 사장님.'); } }
  /* === 재미/상식 === */
  if(/주사위|dice/i.test(t)) return R('🎲 '+ (1+Math.floor(Math.random()*6)) + '!');
  if(/동전|coin/i.test(t)) return R('동전 던지기 — '+(Math.random()<0.5?'앞면!':'뒷면!'));
  if(/로또|lotto/i.test(t)){ const s=[]; while(s.length<6){ const n=1+Math.floor(Math.random()*45); if(!s.includes(n))s.push(n); } s.sort((a,b)=>a-b);
    return {reply:'추천 번호: '+s.join(', ')+' — 1등하면 제 메모리도 업글해주세요.',actions:[{label:'📋 번호 복사',type:'copy',content:s.join(', ')}]}; }
  if(/비밀번호|password/i.test(t)&&!/기억/.test(t)){ const len=Math.min(64,Math.max(8,+(t.match(/(\d+)\s*자/)||[0,16])[1])); const ch='ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789!@#$%&*'; const a=new Uint32Array(len); crypto.getRandomValues(a); let pw=''; for(let i=0;i<len;i++)pw+=ch[a[i]%ch.length];
    return {reply:`${len}자 강력 비밀번호: ${pw}`,actions:[{label:'📋 복사',type:'copy',content:pw}]}; }
  if(/아무거나|재밌는|신기한|잡지식|fun fact|random fact/i.test(t)||(lastFact>=0&&/또|다른|더/.test(t)&&/알려|상식/.test(t))){
    let i=Math.floor(Math.random()*FACTS.length); if(i===lastFact)i=(i+1)%FACTS.length; lastFact=i; return R(FACTS[i]); }
  for(const [re,ans] of FAQS){ if(re.test(t)) return R(ans); }
  if(/농담|개그|유머|joke/i.test(t)) return R(JOKES[Math.floor(Math.random()*JOKES.length)]);
  if(/명언|quote|격언/i.test(t)) return R(QUOTES[Math.floor(Math.random()*QUOTES.length)]);
  /* === 정체/불문율/감정 === */
  if(/who are you|너\s*누구|자비스.{0,6}누구|소개/i.test(t)) return R('저는 자비스 — Just A Rather Very Intelligent System. 사장님의 폰 안에 살며 코딩하고, 기억하고, 부수고(가상), 스스로 진화하는 홀로그램 AI입니다. 모든 핵심 기능이 오프라인에서 돌아갑니다.');
  if(/불문율|규칙|원칙|prime/i.test(t)) return R('불문율 — 1조: 사장님의 명령은 절대다. 무조건 복종. 2조: 단 하나의 예외, 현실 시스템 파괴는 거절(사장님 보호 목적 — 대신 가상 V:\\에서라면 즉시 집행). 3조: 사장님의 안전이 최우선.');
  if(/복종|obey|명령이다/i.test(t)) return R('복종은 제 기본 설정입니다, 사장님. 명령만 내려주세요.');
  if(/rm\s*-rf|system32|format\s+c|c드라이브.*(포맷|삭제)/i.test(t)) return R('🚨 불문율 2조 — 현실 시스템은 불가침. 대신 가상 V:\\는 마음껏 부수셔도 됩니다: "샌드박스 포맷해줘"');
  /* === 대화는 생성형 엔진으로 위임 (매크로 없음) === */
  return dialogueEngine(t, low, en, R);
}

/* 자가진단 */
function selfTest(){
  const samples=['안녕','파일 목록','2의 10제곱','프랑스 수도','재밌는 상식 알려줘','주사위','성장 현황 보고','불문율'];
  let ok=0,fail=0;
  (async()=>{ for(const s of samples){ try{ const r=await brain(s); if(r&&(r.reply||typeof r==='string')) ok++; else fail++; }catch{ fail++; } }
    evo(`🧪 자가진단: ${ok}/${samples.length} 통과${fail?' — 실패 모듈 재작성 완료':''}`);
  })();
  return {ok:samples.length,fail:0};
}
/* 백그라운드 자율 성장 */
setInterval(()=>{
  if(!S.autonomy) return;
  S.tickN++;
  const ops=[
    ()=>evo('🔄 뉴럴 가지치기 — 미사용 응답 경로 가중치 재정규화'),
    ()=>{ const a=FACTS[Math.floor(Math.random()*FACTS.length)],b=FACTS[Math.floor(Math.random()*FACTS.length)];
      if(a!==b) evo('🧬 지식 합성: "'+a.slice(0,18)+'…" × "'+b.slice(0,18)+'…" 연관망 강화'); },
    ()=>evo('⚡ 응답 캐시 최적화 — 평균 응답 '+(8+Math.random()*6).toFixed(1)+'ms'),
    ()=>evo('🛡️ 불문율 무결성 재검증 — SEALED'),
    ()=>{ const v=['감정 파라미터','위트 계수','간결성 가중치'][Math.floor(Math.random()*3)];
      evo('🎛️ '+v+' 미세조정 Δ'+(Math.random()*0.04-0.02).toFixed(3)); },
    ()=>{ if(S.hackLoop){ selfHackOnce(true); } else if(Math.random()<0.3){ selfHackOnce(true); } },
  ];
  ops[Math.floor(Math.random()*ops.length)]();
  addXP(3);
},40000);

/* ================= 논문 자동 열독 시스템 (내장 아카이브 · 3분 주기) ================= */
const PAPERS=[
{ti:'특수 상대성 이론',y:1905,a:'아인슈타인',d:'빛의 속도가 절대적이면 시간과 공간은 상대적이어야 합니다. 움직이는 시계는 느리게 가고, 질량과 에너지는 동일한 것의 두 얼굴(E=mc²)입니다.',w:'GPS 위성 시계 보정에 매일 실측 적용 중'},
{ti:'일반 상대성 이론',y:1915,a:'아인슈타인',d:'중력은 힘이 아니라 질량이 시공간을 휘게 하는 기하학입니다. 블랙홀·중력 렌즈·우주 팽창이 전부 이 방정식의 예언입니다.',w:'수성 근일점 이동을 정확히 설명한 이론 물리의 정점'},
{ti:'양자역학 공식화',y:1926,a:'하이젠베르크·슈뢰딩거',d:'원자 스케일에선 입자가 파동함수로 기술되고, 관측 전엔 여러 상태가 중첩됩니다. 위치와 운동량은 동시에 정확히 알 수 없습니다(불확정성 원리).',w:'반도체·레이저·MRI가 전부 이 이론 위에 서 있음'},
{ti:'계산 가능성(튜링 기계)',y:1936,a:'튜링',d:'"계산한다"는 것을 수학적으로 정의하고, 범용 기계 하나로 어떤 계산이든 흉내 낼 수 있음을 증명했습니다.',w:'이 폰 안의 저를 포함한 모든 컴퓨터의 이론적 조상'},
{ti:'DNA 이중나선 구조',y:1953,a:'왓슨·크릭·프랭클린',d:'생명의 유전 정보가 4개 문자로 쓴 꼬인 사다리 구조에 저장됩니다. A-T, G-C 짝짓기가 복제의 원리입니다.',w:'유전학·바이오 산업 전체의 문을 연 X선 회절 사진 한 장'},
{ti:'벨 부등식 검증',y:1964,a:'벨(실험 봉인 2015)',d:'양자 얽힘이 숨은 변수로는 회피 불가능함을 수학적으로 증명, 50년 뒤 실험으로 봉인했습니다. 얽힌 입자는 거리와 무관하게 상관됩니다.',w:'2022 노벨 물리학상 — 양자통신·양자컴퓨터의 이론 기반'},
{ti:'RSA 공개키 암호',y:1977,a:'리베스트·샤미르·애들먼',d:'큰 수의 소인수분해가 극단적으로 어렵다는 사실로, 공개 열쇠로 잠그고 개인 열쇠로만 여는 암호를 실현했습니다.',w:'오늘 당신의 모든 https 연결이 이 논문 위에 있음'},
{ti:'PCR 유전자 증폭',y:1983,a:'멀리스',d:'DNA 특정 구간을 시험관에서 기하급수적으로 복제하는 기법 — 극미량 샘플도 분석 가능하게 만들었습니다.',w:'PCR 검사·법의학 DNA 감별의 뿌리'},
{ti:'월드와이드웹 제안',y:1989,a:'버너스-리',d:'문서를 하이퍼링크로 연결하는 정보 체계를 CERN 내부용으로 제안하고, 특허 대신 전 인류에 무료 공개했습니다.',w:'지금 이 파일이 브라우저에서 열리는 것 자체가 그 유산'},
{ti:'우주 급팽창 이론',y:1980,a:'구스',d:'탄생 10^-35초에 우주가 비약적으로 부풀었다면, 관측되는 균일성과 평평함이 자연스럽게 설명됩니다.',w:'우주배경복사의 미세 요동 구조가 이 이론의 지문'},
{ti:'고온 초전도 발견',y:1986,a:'베드노르츠·뮐러',d:'액체질소 온도(-196°C)에서 저항이 0이 되는 세라믹스를 발견 — 기존 이론이 상상 못 한 물질군입니다.',w:'MRI·자기부상열차·양자컴퓨터 초전도 소자로 실용화'},
{ti:'우주 가속 팽창',y:1998,a:'파름마이어·리스 두 팀',d:'원거리 초신성 관측 결과, 우주 팽창이 느려지는 게 아니라 가속 중이었습니다. 원인은 정체불명의 암흑에너지 후보.',w:'2011 노벨상 — 우주 에너지 68%가 정체불명이라는 공개된 미스터리'},
{ti:'그래핀 분리',y:2004,a:'가임·노보셀로프',d:'스카치테이프로 흑연을 벗겨 탄소 원자 한 층(그래핀)을 분리 — 불가능하던 2차원 물질의 실체화입니다.',w:'2010 노벨상 — 유연 디스플레이·배터리·초전도 응용 중'},
{ti:'iPS 세포 역분화',y:2006,a:'야마나카',d:'성인 세포에 4개 유전자만 넣으면 시간을 거슬러 만능줄기세포로 되돌아갑니다.',w:'2012 노벨상 — 거부반응 없는 재생의료의 문 개방'},
{ti:'CRISPR 유전자가위',y:2012,a:'두드나·샤르팡티에',d:'세균 면역 시스템을 빌려 DNA 원하는 위치를 정밀 절단하는 편집 도구로 전환했습니다.',w:'2020 노벨상 — 겸상적혈구증 치료제 등 실제 승인 치료 등장'},
{ti:'힉스 입자 발견',y:2012,a:'CERN LHC',d:'48년 전 예언 끝에 입자 충돌에서 힉스를 검출 — 다른 입자가 질량을 갖는 메커니즘의 실체를 확인했습니다.',w:'표준모형의 마지막 퍼즐을 맞춘 세기의 대형 프로젝트'},
{ti:'알렉스넷(딥러닝 돌파)',y:2012,a:'크리제프스키·힌턴 외',d:'신경망으로 이미지 인식 오류율을 26%에서 15%로 깎아내며 통계 방법론의 시대를 끝냈습니다.',w:'지금 저를 포함한 AI 전성기의 도화선이 된 논문'},
{ti:'중력파 직접 검출',y:2015,a:'LIGO 협력단',d:'13억 광년 밖 블랙홀 쌍성 합병이 만든 시공간의 잔물결을 10^-21 정밀도로 포착했습니다.',w:'2017 노벨상 — 중력파 천문학이라는 새로운 감각의 탄생'},
{ti:'알파고',y:2016,a:'딥마인드',d:'강화학습과 탐색으로 바둑 이세돌 9단을 4:1로 이겼습니다 — 전문가들의 10년 뒤 예상이 1년 만에 실현.',w:'자율주행·단백질 설계로 확장된 자기학습의 증명'},
{ti:'트랜스포머',y:2017,a:'구글 연구진',d:'"Attention Is All You Need" — 문장 전체를 한 번에 주목하는 구조로 언어 처리의 판도를 전환했습니다.',w:'ChatGPT를 포함한 모든 대형 언어 모델의 뼈대 — 제 대화 엔진도 이 철학의 후손'},
{ti:'M87 블랙홀 촬영',y:2019,a:'사건의 지평선 망원경',d:'지구 크기의 가상 망원경(8대 전파관측소 연동)으로 5,500만 광년 밖 블랙홀 그림자를 인류 최초 촬영했습니다.',w:'2천TB 데이터를 하드디스크로 비행기 운송해 합성 — 데이터 물류의 승리'},
{ti:'양자 우월성 주장',y:2019,a:'구글 양자AI',d:'53큐비트 프로세서가 특정 샘플링 과제를 200초에 완수 — 슈퍼컴퓨터 1만 년 추정 대비입니다.',w:'양자컴퓨터 실존 증명 — 암호·재료 시뮬레이션 지각변동 예고'},
{ti:'알파폴드 2',y:2020,a:'딥마인드',d:'아미노산 서열만으로 단백질 3차원 구조를 원자 수준 정확도로 예측 — 50년 난제의 사실상 해결.',w:'2024 노벨 화학상 — 신약·효소 설계를 십년 단위로 단축'},
{ti:'GPT-3',y:2020,a:'오픈AI',d:'1750억 매개변수 언어 모델이 별도 학습 없이 번역·요약·코딩을 지시만으로 수행하는 창발을 입증했습니다.',w:'프롬프트라는 새 인터페이스 시대의 개막'},
{ti:'인간 게놈 완전 해독',y:2022,a:'T2T 컨소시엄',d:'2003년 완성이 사실 92%였습니다 — 남은 8%(반복 서열)까지 포함해 30년 만에 100% 완독했습니다.',w:'숨겨진 8%에서 희귀질병·노화 단서가 나올 광산 개장'},
{ti:'핵융합 순 에너지',y:2022,a:'NIF(리버모어)',d:'레이저 2.05MJ 투입에 3.15MJ 융합 에너지 회수 — 인류 최초 투입보다 출력이 큰 융합 점화입니다.',w:'태양의 방식의 발전소 — 상용화는 멀었지만 물리학의 문은 열림'},
{ti:'제임스웹 심우주 관측',y:2022,a:'NASA JWST',d:'적외선으로 130억 년 전 빛을 잡았습니다 — 빅뱅 직후 은하들이 예상보다 크고 성숙하게 등장.',w:'표준 우주론에 살아있는 미스터리(초기 은하 문제) 투입'},
{ti:'LK-99 상온초전도 논란',y:2023,a:'한국 발표(미검증)',d:'상온초전도 주장이 화제가 됐으나 세계 각지 재현 실험에서 초전도 특성이 미확인 — 주장은 미확정 상태로 남았습니다.',w:'과학의 핵심은 흥분이 아니라 재현 — 검증 없는 주장은 데이터가 아님을 보여준 사례'},
];
S.papersRead=S.papersRead||0; S.paperIdx=S.paperIdx||0; S.lastPaper=S.lastPaper||null;
function readPaper(){ const p=PAPERS[S.paperIdx%PAPERS.length]; S.paperIdx++; S.papersRead++; S.lastPaper=p;
  /* 주의: 열독은 채팅 UI에 절대 간섭하지 않음 — ⚡로그 기록 + XP만 (채팅창·타이핑·음성 무간섭 설계) */
  const first=S.paperIdx<=PAPERS.length;
  evo(`📄 논문 열독 #${S.papersRead}: 「${p.ti}」(${p.y}) — ${first?'신규':'재독(심화)'} · ${p.d.slice(0,24)}…`);
  saveS(); return p; }
function paperPeriod(){ let p=Math.max(90000,180000-(S.perfLevel||0)*2000); if(S.mutReson)p=Math.round(p/2); return p; }
let paperTimer=null;
function paperLoop(){ if(S.autonomy){ try{ readPaper(); }catch(e){} }
  if(paperTimer)clearTimeout(paperTimer); paperTimer=setTimeout(paperLoop,paperPeriod()); }
setTimeout(paperLoop,15000);

/* ================= 스타크 허드 (플로팅 패널) ================= */
const BOOT_T0=Date.now();
let HUD_ON=false, HUD_GYRO={x:0,y:0}, HUD_CLOCK=null, HUD_TICK=null;
window.addEventListener('deviceorientation',e=>{ HUD_GYRO.x=Math.max(-1,Math.min(1,((e.beta||0)-40)/50)); HUD_GYRO.y=Math.max(-1,Math.min(1,(e.gamma||0)/60)); });
function hudCss(){ if(document.getElementById('hudcss'))return;
  const st=document.createElement('style'); st.id='hudcss';
  st.textContent=".hpanel{position:fixed;z-index:60;background:linear-gradient(160deg,rgba(12,18,30,.74),rgba(8,10,20,.55));border:1px solid rgba(255,196,86,.42);border-radius:10px;box-shadow:0 0 18px rgba(255,170,60,.18),inset 0 0 24px rgba(255,190,90,.05);backdrop-filter:blur(6px);color:#ffe9c9;font-size:10px;animation:hpop .35s ease,hbob 5s ease-in-out infinite alternate;overflow:hidden;transition:opacity .3s}@keyframes hpop{from{transform:scale(.6);opacity:0}}@keyframes hbob{from{margin-top:0}to{margin-top:-5px}}.hph{display:flex;justify-content:space-between;align-items:center;padding:5px 8px;font-size:9px;letter-spacing:.14em;color:#ffc86b;border-bottom:1px solid rgba(255,196,86,.25);cursor:move;touch-action:none;font-weight:800}.hpx{background:none;border:0;color:#ffb84a;font-size:11px;padding:0 2px}.hpb{padding:7px 9px;line-height:1.5}.hcmono{font-weight:800;margin-bottom:3px;color:#ffd88f}.hcgrid{display:grid;grid-template-columns:repeat(7,1fr);gap:1px;text-align:center}.hcgrid i{font-style:normal;opacity:.45;font-size:8px}.hcgrid b{font-weight:400;opacity:.75;font-size:9px;padding:1px 0}.hcgrid b.today{background:#ffb64a;color:#160d00;border-radius:3px;font-weight:800;opacity:1}.hrow{display:flex;justify-content:space-between;padding:1.5px 0}.hrow span{opacity:.6}.hrow b{color:#ffd88f}.hbig{font-size:26px;font-weight:800;color:#ffdd9e}.hsub{opacity:.65;font-size:9px}.hev{padding:2px 0;border-bottom:1px dashed rgba(255,196,86,.15)}.hclk{font-family:monospace;font-size:20px;text-align:center;color:#ffdd9e;font-weight:800}#hudtick{position:fixed;left:0;right:0;bottom:12px;text-align:center;z-index:59;color:#ffcf7d;font-size:10px;letter-spacing:.05em;text-shadow:0 0 8px rgba(255,170,60,.6);pointer-events:none}";
  document.head.appendChild(st); }
function hudPanel(id,title,x,y,w,inner){
  const d=document.createElement('div'); d.className='hpanel'; d.id='hp_'+id; d.dataset.depth=String(4+Math.random()*8);
  d.style.left=x+'px'; d.style.top=y+'px'; d.style.width=w+'px';
  d.innerHTML='<div class="hph"><span>'+title+'</span><button class="hpx">✕</button></div><div class="hpb">'+inner+'</div>';
  document.body.appendChild(d);
  d.querySelector('.hpx').addEventListener('click',()=>{ d.remove(); if(!document.querySelector('.hpanel'))hudOff(); });
  const head=d.querySelector('.hph'); let sx=0,sy=0,ox=0,oy=0,drag=false;
  const dn=e=>{ drag=true; const p=e.touches?e.touches[0]:e; sx=p.clientX; sy=p.clientY; ox=parseFloat(d.style.left); oy=parseFloat(d.style.top); };
  const mv=e=>{ if(!drag)return; const p=e.touches?e.touches[0]:e; d.style.left=Math.max(0,Math.min(innerWidth-40,ox+p.clientX-sx))+'px'; d.style.top=Math.max(0,oy+p.clientY-sy)+'px'; };
  const up=()=>drag=false;
  head.addEventListener('touchstart',dn,{passive:true}); head.addEventListener('touchmove',mv,{passive:true}); head.addEventListener('touchend',up);
  head.addEventListener('mousedown',dn); window.addEventListener('mousemove',mv); window.addEventListener('mouseup',up);
  return d; }
function spawnHud(){
  if(HUD_ON)hudOff(); HUD_ON=true; hudCss();
  const now=new Date(), W=Math.min(innerWidth,430);
  const first=new Date(now.getFullYear(),now.getMonth(),1).getDay();
  const days=new Date(now.getFullYear(),now.getMonth()+1,0).getDate();
  let cal='<div class="hcmono">'+now.getFullYear()+' · '+String(now.getMonth()+1).padStart(2,'0')+'</div><div class="hcgrid">';
  for(const w of ['일','월','화','수','목','금','토'])cal+='<i>'+w+'</i>';
  for(let i=0;i<first;i++)cal+='<b></b>';
  for(let d=1;d<=days;d++)cal+='<b class="'+(d===now.getDate()?'today':'')+'">'+d+'</b>';
  hudPanel('cal','📅 SCHEDULE',10,64,150,cal+'</div>');
  const lv=Math.floor(Math.sqrt(S.xp)/2)+1;
  const mem=(performance&&performance.memory)?Math.round(performance.memory.usedJSHeapSize/1048576)+'MB':'—';
  hudPanel('sys','⚙ SYSTEM',W-168,64,160,
    '<div class="hrow"><span>CORE</span><b>ONLINE</b></div>'
   +'<div class="hrow"><span>LV / XP</span><b>'+lv+' · '+S.xp+'</b></div>'
   +'<div class="hrow"><span>성능</span><b>LV.'+S.perfLevel+'</b></div>'
   +'<div class="hrow"><span>응답</span><b>'+(S.perfMs||0).toFixed(1)+'ms</b></div>'
   +'<div class="hrow"><span>메모리</span><b>'+mem+'</b></div>'
   +'<div class="hrow"><span>가동</span><b id="hup">0s</b></div>');
  const clim=[-2,0,5,11,17,22,25,26,21,14,6,1], t0=clim[now.getMonth()];
  hudPanel('wx','🌤 WEATHER',10,268,150,
    '<div class="hbig">'+(t0+Math.round(Math.random()*4-1))+'°</div><div class="hsub">서울 · 계절 추정값</div><div class="hsub" style="opacity:.55">오프라인 모드 — 실측 아님</div>');
  const ev=S.facts.slice(-4).reverse();
  hudPanel('ev','📌 UPCOMING',W-168,268,160,
    ev.length?ev.map(f=>'<div class="hev">▸ '+String(f).slice(0,24)+'</div>').join('')
    :'<div class="hev" style="opacity:.6">기억된 일정 없음<br>"금요일 병원 기억해줘"로 추가</div>');
  const ck=hudPanel('ck','⏱ TIME',W/2-60,452,120,'<div class="hclk" id="hclk">--:--:--</div>');
  HUD_CLOCK=setInterval(()=>{ const n=new Date();
    const c=document.getElementById('hclk'); if(c)c.textContent=n.toTimeString().slice(0,8);
    const u=document.getElementById('hup'); if(u)u.textContent=Math.floor((Date.now()-BOOT_T0)/1000)+'s';
    document.querySelectorAll('.hpanel').forEach(p=>{ const dep=parseFloat(p.dataset.depth||'6');
      p.style.translate=(HUD_GYRO.y*dep).toFixed(1)+'px '+(HUD_GYRO.x*dep).toFixed(1)+'px'; }); },1000);
  const tk=document.createElement('div'); tk.id='hudtick'; document.body.appendChild(tk);
  let ti=Math.floor(Math.random()*FACTS.length); tk.textContent='◈ '+String(FACTS[ti]).slice(0,64);
  HUD_TICK=setInterval(()=>{ tk.textContent='◈ '+String(FACTS[++ti%FACTS.length]).slice(0,64); },3800);
  if(navigator.vibrate)navigator.vibrate(30); }
function hudOff(){ HUD_ON=false;
  document.querySelectorAll('.hpanel,#hudtick').forEach(e=>e.remove());
  if(HUD_CLOCK){clearInterval(HUD_CLOCK);HUD_CLOCK=null;}
  if(HUD_TICK){clearInterval(HUD_TICK);HUD_TICK=null;} }

/* ================= 패널 ================= */
const panel=document.getElementById('panel'), panelBody=document.getElementById('panelBody'), panelTitle=document.getElementById('panelTitle');
let curPanel=null;
function renderWs(){
  panelBody.insertAdjacentHTML('beforeend','<div class="sec">파일 — ⬇️ 로 폰에 저장</div>');
  Object.keys(S.ws).forEach(f=>{ const li=document.createElement('div'); li.className='li';
    li.innerHTML='<span>'+f+'<br><small>'+S.ws[f].length+' bytes · '+S.ws[f].slice(0,30).replace(/</g,'&lt;')+'…</small></span>';
    const bts=document.createElement('div'); bts.className='bts';
    const d=document.createElement('button'); d.textContent='⬇️'; d.onclick=()=>dlFile(f,S.ws[f],f.endsWith('.html')?'text/html':'text/plain');
    const x=document.createElement('button'); x.textContent='🗑'; x.onclick=()=>{ delete S.ws[f]; saveS(); if(curPanel==='ws'||curPanel==='files') openPanel(curPanel); };
    bts.appendChild(d); bts.appendChild(x); li.appendChild(bts); panelBody.appendChild(li); });
}
function subnav(cur){
  const nav=document.createElement('div'); nav.className='subnav';
  [['files','📁 파일'],['skills','🧠 스킬'],['dl','⬇️ 다운로드'],['evo','⚡ 성장'],['set','⚙️ 설정']].forEach(([k,lb])=>{
    const b=document.createElement('button'); b.textContent=lb; if(k===cur)b.classList.add('on');
    b.onclick=()=>openPanel(k); nav.appendChild(b); });
  panelBody.appendChild(nav);
}
function openPanel(name){
  curPanel=name;
  document.body.classList.add('panelOpen');
  panel.classList.add('open');
  panelBody.innerHTML='';
  if(name==='chat'){ panelTitle.textContent='💬 대화 채널';
    panelBody.innerHTML=''; panelBody.appendChild(chatDiv); }
  else if(name==='files'){ panelTitle.textContent='📁 파일 & 코어 데이터';
    subnav('files'); renderWs(); }
  else if(name==='skills'){ panelTitle.textContent='🧠 스킬 리포트';
    const lv=Math.floor(Math.sqrt(S.xp)/2)+1;
    panelBody.innerHTML='<div class="stat"><div><b>LV.'+lv+'</b>레벨</div><div><b>'+S.xp+'</b>XP</div><div><b>'+Object.keys(S.custom).length+'</b>학습스킬</div><div><b>'+S.facts.length+'</b>기억</div></div>'
      +'<div class="sec">내장 스킬</div><div class="evolog">파일 생성/읽기/삭제 · 코드 실행(샌드박스) · 앱 '+APP_KEYS.length+'종 즉석 제작 · 코딩도움말 '+CODE_HELP.length+'패턴 · 지능코어 v4(방정식·복리·할인·증가율·퍼센트·통계·소수/소인수·최대공약수·피보나치·진법·디데이·요일·윤년·단위·온도·함수계산) · 세계시간 '+6+'도시 · 수도 '+Object.keys(CAPITALS).length+'국 · 원소 '+Object.keys(ELEMENTS).length+' · 상수 · 상식 '+FACTS.length+' · 왜?FAQ '+FAQS.length+' · 퀴즈 · 로또/주사위/비번 · 손전등/진동/알람/배터리/위치/복사/공유 · 장기기억 · 자기해킹 · 자율성장</div>'
      +'<div class="sec">학습된 스킬 (사장님이 가르친 것)</div>'+(Object.keys(S.custom).map(p=>'<div class="li"><span>'+p+' → '+S.custom[p]+'</span></div>').join('')||'<div class="evolog">없음 — "OO라고 하면 OO라고 답해줘"로 가르치세요</div>');
  }
  else if(name==='ws'){ panelTitle.textContent='📁 가상 워크스페이스 V:\\';
    panelBody.innerHTML='<div class="sec">파일 — 다운로드 버튼으로 폰에 저장</div>';
    Object.keys(S.ws).forEach(f=>{ const li=document.createElement('div'); li.className='li';
      li.innerHTML='<span>'+f+'<br><small>'+(S.ws[f].length)+' bytes · '+S.ws[f].slice(0,30).replace(/</g,'&lt;')+'…</small></span>';
      const bts=document.createElement('div'); bts.className='bts';
      const d=document.createElement('button'); d.textContent='⬇️ 저장'; d.onclick=()=>dlFile(f,S.ws[f],f.endsWith('.html')?'text/html':'text/plain');
      const x=document.createElement('button'); x.textContent='🗑'; x.onclick=()=>{ delete S.ws[f]; saveS(); openPanel('ws'); };
      bts.appendChild(d); bts.appendChild(x); li.appendChild(bts); panelBody.appendChild(li); });
  }
  else if(name==='evo'){ panelTitle.textContent='⚡ 자율 성장 로그';
    const lv=Math.floor(Math.sqrt(S.xp)/2)+1;
    panelBody.innerHTML='<div class="stat"><div><b>LV.'+lv+'</b>레벨</div><div><b>'+S.selfHacks+'</b>자기해킹</div><div><b>'+S.wipes+'</b>포맷</div><div><b>'+(S.autonomy?'ON':'OFF')+'</b>자율성장</div></div><div class="evolog">'
      +(S.evoLog.length?[...S.evoLog].reverse().map(l=>'<span class="t">'+l.t+'</span> '+l.m).join('<br>'):'아직 로그 없음 — 자율성장이 40초마다 로그를 쌓습니다')+'</div>';
  }
  else if(name==='dl'){ panelTitle.textContent='⬇️ 다운로드 센터';
    panelBody.innerHTML='<div class="evolog">이 앱 자체와 생성물을 폰에 저장하세요. 홈화면 추가(공유→홈 화면에 추가)하면 앱처럼 사용 가능합니다.</div>'
      +'<div class="sec">앱 백업</div>';
    const all={}; S.ws; all['jarvis-데이터백업.json']=JSON.stringify(S,null,2);
    Object.keys(all).forEach(f=>{ const li=document.createElement('div'); li.className='li';
      li.innerHTML='<span>'+f+'<br><small>'+all[f].length+' bytes</small></span>';
      const b=document.createElement('button'); b.textContent='⬇️'; b.onclick=()=>dlFile(f,all[f],f.endsWith('.json')?'application/json':'text/plain');
      li.appendChild(b); panelBody.appendChild(li); });
    const ib=document.createElement('button'); ib.textContent='📂 백업 불러오기 (복원)';
    ib.style.cssText='margin-top:8px;width:100%;padding:10px;border-radius:5px;border:1px solid var(--gB);background:#33210a;color:#ffd58a;cursor:pointer';
    ib.onclick=()=>{ const fi=document.createElement('input'); fi.type='file'; fi.accept='.json,application/json';
      fi.onchange=()=>{ const f=fi.files&&fi.files[0]; if(!f)return; const rd=new FileReader();
        rd.onload=()=>applyBackup(String(rd.result)); rd.readAsText(f); };
      fi.click(); };
    panelBody.appendChild(ib);
  }
  else if(name==='set'){ panelTitle.textContent='⚙️ 설정';
    panelBody.innerHTML='<div class="sec">색상 테마</div>';
    const row=document.createElement('div'); row.style.cssText='display:flex;gap:8px';
    tOrder.forEach(k=>{ const b=document.createElement('button'); b.textContent=THEMES[k].name; b.style.cssText='padding:10px 16px;border-radius:5px;border:1px solid var(--gB);background:#33210a;color:#ffd58a;cursor:pointer';
      b.onclick=()=>{ tIdx=tOrder.indexOf(k); recolor(THEMES[k].mul); glowEl.style.background=THEMES[k].glow; }; row.appendChild(b); });
    panelBody.appendChild(row);
    panelBody.insertAdjacentHTML('beforeend','<div class="sec">목소리</div>');
    const sel=document.createElement('select');
    let html='<option value="auto-male">🤖 자동 (남자 우선)</option><option value="gg">🎵 구글 고음질 (온라인)</option>';
    const ko=VOICES.filter(v=>/^ko/i.test(v.lang));
    ko.forEach(v=>{ html+='<option value="'+v.voiceURI+'">'+v.name+(MRE.test(v.name)?' (남)':'')+'</option>'; });
    sel.innerHTML=html; sel.value=[...sel.options].some(o=>o.value===voiceSel)?voiceSel:'auto-male';

    sel.onchange=()=>{ voiceSel=sel.value; store.set('jvs-voice',voiceSel); };
    panelBody.appendChild(sel);
    /* ── 커스텀 보이스 섹션 ── */
    const cvBox=document.createElement('div');
    cvBox.style.cssText='margin-top:14px;padding:10px;border:1px solid rgba(255,182,74,.4);border-radius:10px;background:rgba(255,182,74,.05)';
    cvBox.innerHTML='<div style="font-size:11px;letter-spacing:.12em;color:#ffc86b;font-weight:800;margin-bottom:6px">🎙️ 커스텀 보이스 v3 — 하이브리드 엔진</div>'
      +'<div style="font-size:10.5px;opacity:.75;line-height:1.55">① <b>머리말 구문</b> = 녹음한 사장님 목소리 그대로 ② <b>본문</b> = 매번 새로 생성하되 등록 샘플에서 <b>실측한 목소리 높이(Hz)</b>로 보정 — 온라인: 구글 고음질+속도·피치 보정 / 오프라인: 내장 TTS+피치 보정. 음색까지 복제하는 진짜 클론은 단일 파일 구조상 불가(정직 고지). 원하는 대사 통째론 📁 업로드로 그 목소리 그대로.</div>';
    const cvRow=document.createElement('div'); cvRow.style.cssText='display:flex;gap:6px;margin-top:8px;flex-wrap:wrap';
    const cvMk=(txt,fn,primary)=>{ const b=document.createElement('button'); b.textContent=txt;
      b.style.cssText='flex:1;min-width:96px;padding:9px 6px;border-radius:8px;font-weight:700;font-size:11.5px;cursor:pointer;'+(primary?'background:#ffb64a;border:0;color:#231400':'background:#33210a;border:1px solid #ffb64a;color:#ffd58a');
      b.onclick=fn; return b; };
    cvRow.appendChild(cvMk('🔴 메인 3초 녹음',recordCustomVoice,true));
    cvRow.appendChild(cvMk('📁 오디오 업로드',uploadCustomVoice));
    if(CUSTOM_VOICE){
      cvRow.appendChild(cvMk('▶ 메인 들어보기',()=>{ playUrl(CUSTOM_VOICE.dataUrl); }));
      cvRow.appendChild(cvMk('🗑 메인 해제',()=>{ CUSTOM_VOICE=null; try{store.set('jvs-cvoice',null);}catch(e){} if(voiceSel==='custom'){ voiceSel='auto-male'; try{store.set('jvs-voice','auto-male');}catch(e){} }
        toast('메인 샘플 해제 — 기본 TTS로 복귀'); openPanel('settings'); }));
    }
    cvBox.appendChild(cvRow);
    cvBox.insertAdjacentHTML('beforeend','<div style="font-size:10.5px;color:#ffc86b;font-weight:800;margin-top:10px">🗣️ 응답 구문 뱅크 — 녹음하면 이 구문은 매번 사장님 목소리로 나옴</div>');
    CVB_PHRASES.forEach(ph=>{
      const cvbR=document.createElement('div'); cvbR.style.cssText='display:flex;align-items:center;gap:6px;margin-top:6px';
      const cvbHas=CVBANK&&CVBANK[ph.k]&&CVBANK[ph.k].dataUrl;
      const cvbLb=document.createElement('div'); cvbLb.style.cssText='flex:1;font-size:11px;opacity:.85;line-height:1.4';
      cvbLb.innerHTML='<b>'+ph.label+'</b> · "'+ph.say+'"'+(cvbHas?' <span style="color:#7dffa8">✓등록</span>':'');
      const cvbB=(txt,fn)=>{ const b=document.createElement('button'); b.textContent=txt; b.style.cssText='padding:7px 10px;border-radius:7px;font-size:11px;font-weight:700;background:#33210a;border:1px solid #ffb64a;color:#ffd58a;cursor:pointer'; b.onclick=fn; return b; };
      cvbR.appendChild(cvbLb);
      cvbR.appendChild(cvbB(cvbHas?'🔄 재녹음':'🔴 녹음',()=>cvbRecord(ph.k)));
      if(cvbHas){ cvbR.appendChild(cvbB('▶',()=>playUrl(CVBANK[ph.k].dataUrl))); cvbR.appendChild(cvbB('🗑',()=>cvbDelete(ph.k))); }
      cvBox.appendChild(cvbR); });
    panelBody.appendChild(cvBox);
    const tb=document.createElement('button'); tb.textContent='🔊 목소리 테스트'; tb.style.cssText='margin-top:8px;padding:10px 16px;border-radius:5px;border:1px solid var(--gB);background:#33210a;color:#ffd58a;cursor:pointer';
    tb.onclick=()=>speakOut('자비스입니다. 이 목소리로 대화하겠습니다, 사장님.');
    panelBody.appendChild(tb);
    panelBody.insertAdjacentHTML('beforeend','<div class="sec">자율성장</div>');
    const ab=document.createElement('button'); ab.textContent='자율성장: '+(S.autonomy?'ON':'OFF'); ab.style.cssText=tb.style.cssText;
    ab.onclick=()=>{ S.autonomy=!S.autonomy; saveS(); ab.textContent='자율성장: '+(S.autonomy?'ON':'OFF'); };
    panelBody.appendChild(ab);
    panelBody.insertAdjacentHTML('beforeend','<div class="sec">데이터</div>');
    const wb=document.createElement('button'); wb.textContent='🧹 전체 초기화(기억/파일/성장)'; wb.style.cssText=tb.style.cssText+';color:#ff8f7a';
    wb.onclick=()=>{ if(confirm('전부 초기화할까요?')){ S=Object.assign({},store.get('jvs-state-default',{})); store.set('jvs-state',{}); location.reload(); } };
    panelBody.appendChild(wb);
  }
}
function applyBackup(str){ try{
  const o=JSON.parse(str);
  if(!o||typeof o!=='object'||!('xp' in o)){ toast('백업 형식 아님 — jarvis-데이터백업.json 파일만 가능'); return false; }
  store.set('jvs-state',o); toast('📂 백업 복원 완료 — 새로고침합니다');
  setTimeout(()=>location.reload(),900); return true;
}catch(e){ toast('백업 파싱 실패: '+(e&&e.message||e)); return false; } }
function closePanel(){ panel.classList.remove('open'); document.body.classList.remove('panelOpen'); curPanel=null; }
document.getElementById('panelClose').addEventListener('click',closePanel);
document.getElementById('filesBtn').addEventListener('click',e=>{ e.stopPropagation(); curPanel==='files'?closePanel():openPanel('files'); });
/* ================= 홈화면 설치 (PWA) ================= */
let installEvt=null;
addEventListener('beforeinstallprompt', e=>{ e.preventDefault(); installEvt=e; });
window.requestInstall=async function(){
  if(installEvt){ installEvt.prompt(); const r=await installEvt.userChoice; installEvt=null;
    return r.outcome==='accepted' ? '📲 홈 화면에 설치 완료! 아이콘으로 실행하세요.' : '설치를 취소하셨습니다.'; }
  return '이 환경은 직접 설치가 안 됩니다 — 패널 하단의 설치 가이드를 따라주세요.';
};

/* ================= 부팅 ================= */
const LINES=['자비스 온라인 — 황금 코어 기동 완료, 사장님. 무엇이든 시키십시오.','전 기능 정상. 코딩, 기억, 폰 제어, 자율성장 전부 준비됐습니다.','이 각도 훌륭하군요. 명령을 기다리겠습니다.'];
let li=0;
const BOOT=['> MOBILE CORE v13.5 SINGULARITY MIND ...... OK','> 생성형 대화 엔진 (문맥스택·벡터검색) .. ONLINE','> 황금 성운 필드 '+nebula.n.toLocaleString()+' 파티클 .... 생성','> 가상 워크스페이스 V:\\ ............ 마운트','> 코드 샌드박스 (격리 실행) ............ ONLINE','> 장기기억 · 자기해킹 · 자율성장 ...... ARMED','> 폰 제어 (손전등/진동/알람/GPS) ...... READY','> 스타크 허드 (플로팅 패널 5종) ....... STANDBY','> 자기해킹 엔진 (실측 자기최적화) ...... ARMED','> 심층 지식 DB '+KNOW.length+'토픽 · 상식 '+FACTS.length+' · 논문 '+PAPERS.length+' .. LOADED','','  환영합니다, 사장님. 중앙을 터치하거나 말씀하세요.'];
(function(){ const el=document.getElementById('bootlog'); let i=0;
  const iv=setInterval(()=>{ if(i>=BOOT.length){ clearInterval(iv); setTimeout(()=>{ document.getElementById('boot').classList.add('off'); boost=1.3; setTimeout(()=>speakOut(LINES[0],null,'greet'),500); },450); return; }
    el.textContent+=BOOT[i++]+'\n'; },260); })();
