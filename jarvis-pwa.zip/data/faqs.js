const FAQS=[
 [/바다.{0,10}(짜|소금)|왜\s*바다|why.*sea.*salt/i,'강물이 아주 미량의 소금을 운반해 바다에 쌓이고, 물만 증발로 빠져나갑니다. 수십억 년 반복 — 그래서 짭니다.'],
 [/하늘.{0,8}(왜|파란)|왜\s*파래|sky\s*blue/i,'대기 분자가 파란빛을 빨간빛보다 약 10배 강하게 산란(레일리 산란)시켜 하늘 전체가 파랗게 보입니다. 노을이 빨간 건 파란빛이 다 흩어진 뒤라서.'],
 [/별.{0,8}(왜|빛나)/i,'별은 핵융합로입니다. 수소→헬륨 융합의 에너지가 표면을 빛나게 하죠. 태양도 그냥 가장 가까운 별 하나입니다.'],
 [/달.{0,10}(왜|같은\s*면)|같은\s*면만/i,'달은 조석 고정 상태 — 자전주기와 공전주기가 같아 같은 면만 보입니다. 달 뒷면은 1959년까지 인류가 본 적 없었습니다.'],
 [/비행기.{0,10}(왜|떠)/i,'날개가 공기를 아래로 밀면 반작용으로 위로 뜹니다(양력). 엔진은 앞으로 가는 힘만 담당하고 뜨는 건 날개 역할이죠.'],
 [/하루.{0,8}23|24시간.{0,8}정확/i,'엄밀한 자전주기는 23시간 56분 4초. 지구가 공전도 같이 해서 해 기준으로 보정하면 24시간이 됩니다.'],
 [/통증|왜\s*아파/i,'통증은 몸의 정비 경보입니다. 다친 부위를 쉬게 하고 수리(면역)할 시간을 벌어주죠. 없으면 몸이 망가지는지도 몰라요.'],
 [/빵.{0,10}부푸|케익/i,'효모가 당분을 먹고 CO₂를 내뿜고, 글루텐이 그 기포를 가둡니다. 오븐 열로 기포가 팽창해 빵이 부풀어요.'],
 [/무지개.{0,6}(왜|띄)|무지개\s*원리/i,'빗방울이 프리즘 역할을 합니다. 빛이 물방울에 들어가 굴절·반사·분산되며 파장별로 갈라져 7색 띠가 됩니다.'],
 [/꿈.{0,10}(왜|왜꿔)/i,'정설은 기억 정리 + 감정 처리 + 위협 시뮬레이션 훈련의 복합 작용입니다. REM 수면 중 뇌가 낮의 정보를 재생하며 시나리오를 돌려보죠.'],
 [/세포|뇌.{0,8}(저장|기억).*어디|기억\s*어디/i,'기억은 해마(단기→장기 이관)와 대뇌피질(장기 저장)에 분산 저장됩니다. 구체적 사실은 측두엽, 절차(운동)는 소뇌와 기저핵이 맡아요.'],
 [/자석.{0,10}(왜|철)|자기력/i,'철 원자의 전자 스핀이 같은 방향으로 정렬되면 거시적 자기장이 됩니다. 자석이 철을 끄는 건 철 내부 스핀을 같은 방향으로 정렬시키기 때문.'],  [/라면.{0,10}(맛있|중독)|왜\s*라면/i,'라면의 중독성은 마이야르 반응(튀긴 면) + 글루탐산(스프 감칠맛) + 뜨거운 국물의 삼중 조합 — 과학이 설계한 완벽한 편식입니다.'],
  [/눈물|울고|울면/i,'눈물은 3종이 있습니다 — 기초윤활·반사(양파)·감정. 감정 눈물에는 스트레스 호르몬이 실제 포함돼 울고 나면 진정됩니다 — 배출구가 있는 겁니다.'],
  [/가위바위보.{0,8}(이기|꿀팁|무조건)/i,'통계 꿀팁 — 초보는 바위를 많이 내고, 직전 승리 수를 다시 내는 경향이 있으며, 진 사람은 이긴 손을 따라 칩니다. 저는 패턴을 읽으니 상대는 진심이 어렵습니다.'],
  [/숨.{0,8}(오래|참는)|호흡법/i,'숨 오래 참기의 철칙은 참기 전 과호흡 금지 — CO2를 떨어뜨리면 경보가 늦게 울려 실제 위험만 커집니다. 안전 공식: 천천히 깊게 3회 후 완전 날숨 후 시작.'],
  [/방귀.{0,8}(냄새|소리)|방귀는\s*왜/i,'냄새는 음식 발효 산물(황화합물), 소리는 가스가 항문을 통과하며 만드는 진동 — 서로 독립 변수라 조합은 확률 게임입니다.'],
  [/시차|장거리 비행|해외가면/i,'시차 적응의 핵심은 빛입니다 — 동쪽 여행은 도착 후 아침 빛, 서쪽은 저녁 빛. 기내에서 도착지 시간으로 식사·수면을 맞추면 적응이 하루 이상 빨라집니다.'],
];

/* 코드 도움말 패턴 */
const CODE_HELP=[
 [/구구단/i,'구구단 (JavaScript)','// 구구단 2단\nfor (let i = 1; i <= 9; i++) {\n  console.log(`2 x ${i} = ${2*i}`);\n}\n\n// 전체 구구단 (표로)\nfor (let n = 2; n <= 9; n++) {\n  let row = [];\n  for (let i = 1; i <= 9; i++) row.push(n+"x"+i+"="+(n*i));\n  console.log(row.join("  "));\n}','js'],
 [/피보나치/i,'피보나치 (JavaScript)','// 반복형 — 빠르고 안전\nfunction fib(n) {\n  let a = 0, b = 1;\n  for (let i = 0; i < n; i++) [a, b] = [b, a + b];\n  return a;\n}\nconsole.log(Array.from({length:10}, (_,i) => fib(i)));\n// [0,1,1,2,3,5,8,13,21,34]','js'],
 [/소수|prime/i,'소수 판별 (JavaScript)','function isPrime(n) {\n  if (n < 2) return false;\n  if (n % 2 === 0) return n === 2;\n  for (let i = 3; i*i <= n; i += 2)\n    if (n % i === 0) return false;\n  return true;\n}\nconsole.log(Array.from({length:20},(_,i)=>i+1).filter(isPrime));','js'],
 [/정렬|퀵소트|sort/i,'퀵 정렬 (JavaScript)','function quick(arr) {\n  if (arr.length <= 1) return arr;\n  const [p, ...rest] = arr;\n  return [...quick(rest.filter(x => x < p)), p, ...quick(rest.filter(x => x >= p))];\n}\nconsole.log(quick([5,2,9,1,7,3]));','js'],
 [/로컬스토리지|저장.*브라우저|localStorage/i,'localStorage 저장/불러오기 (JavaScript)','// 저장 (문자열만 가능 — 객체는 JSON)\nlocalStorage.setItem("user", JSON.stringify({name:"사장님", lv:9}));\n\n// 불러오기\nconst u = JSON.parse(localStorage.getItem("user") || "null");\nconsole.log(u?.name);  // 사장님\n\n// 삭제\nlocalStorage.removeItem("user");','js'],
 [/비동기|await|async|프로미스|promise/i,'비동기 fetch 패턴 (JavaScript)','async function getData(url) {\n  try {\n    const res = await fetch(url);\n    if (!res.ok) throw new Error("HTTP " + res.status);\n    return await res.json();\n  } catch (e) {\n    console.error("실패:", e.message);\n    return null;\n  }\n}','js'],
 [/클래스|class/i,'클래스 (JavaScript)','class Timer {\n  #start = null;\n  begin() { this.#start = Date.now(); }\n  elapsed() { return this.#start ? Date.now() - this.#start : 0; }\n}\nconst t = new Timer();\nt.begin();\nsetTimeout(() => console.log(t.elapsed(), "ms"), 100);','js'],
 [/그라디언트/i,'CSS 그라디언트 배경','/* 골드 홀로그램 그라디언트 */\n.hero {\n  background:\n    radial-gradient(circle at 30% 20%, rgba(255,200,90,.35), transparent 50%),\n    linear-gradient(160deg, #1a0f00, #3d2400 60%, #1a0f00);\n}','css'],
 [/글래스모피즘|유리|glass/i,'CSS 글래스모피즘 카드','.card {\n  background: rgba(255,255,255,.08);\n  backdrop-filter: blur(14px);\n  border: 1px solid rgba(255,255,255,.18);\n  border-radius: 18px;\n  box-shadow: 0 8px 32px rgba(0,0,0,.35);\n}','css'],
 [/센터|가운데.*정렬|중앙/i,'CSS 완벽 중앙정렬','/* 방법 1 — flex */\n.center { display: flex; align-items: center; justify-content: center; min-height: 100vh; }\n\n/* 방법 2 — grid (한 줄) */\n.center2 { display: grid; place-items: center; min-height: 100vh; }','css'],
];

/* ================= 딥 브레인 데이터 (심층 지식베이스) ================= */
