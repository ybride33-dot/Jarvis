/* J.A.R.V.I.S Service Worker — 설치 후 완전 오프라인 (캐시 우선·백그라운드 갱신) */
const CV='jarvis-v4-mind-1';
const ASSETS=['./','./index.html','./app.js','./manifest.json','./icon-192.png','./icon-512.png',
'./data/facts.js','./data/faqs.js','./data/know-core.js','./data/know-pack1.js','./data/know-pack2.js',
'./data/know-pack3.js','./data/know-pack4.js','./data/know-pack5.js','./data/know-pack6.js'];
self.addEventListener('install',e=>{ e.waitUntil(caches.open(CV).then(c=>c.addAll(ASSETS)).then(()=>self.skipWaiting())); });
self.addEventListener('activate',e=>{ e.waitUntil(caches.keys().then(ks=>Promise.all(ks.filter(k=>k!==CV).map(k=>caches.delete(k)))).then(()=>self.clients.claim())); });
self.addEventListener('fetch',e=>{ const r=e.request; if(r.method!=='GET')return;
  const u=new URL(r.url); if(u.origin!==location.origin)return;
  e.respondWith(caches.match(r,{ignoreSearch:true}).then(hit=>{
    const net=fetch(r).then(res=>{ if(res&&res.ok){ const cp=res.clone(); caches.open(CV).then(c=>c.put(r,cp)); } return res; }).catch(()=>hit);
    if(hit)return net&&hit?hit:hit||net; /* 캐시 즉시 + 백그라운드 갱신 */
    if(r.mode==='navigate'){ return caches.match('./index.html').then(ih=>ih||net); }
    return net; })); });
